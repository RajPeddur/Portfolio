/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: 'var(--primaryColor)',
        secondary: 'var(--secondaryColor)',
        accent: 'var(--accentColor)',
        textColor: 'var(--textColor)',
        background: 'var(--backgroundColor)',
      },
      borderRadius: {
        DEFAULT: 'var(--borderRadius)',
      },
      fontFamily: {
        inter: 'var(--fontFamily)',
      },
    },
  },
  plugins: [require('daisyui')],
  daisyui: { themes: ['light', 'dark'] },
};
