import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { localData } from "../api/utils";
import apiClient from "../api/apiClient";

interface AuthState {
  user: { email: string; token: string } | null;
  loading: boolean;
  error: string | null;
}

const initialState: AuthState = {
  user: localData.load("user") || null, // ✅ load persisted user
  loading: false,
  error: null,
};

// Mock login API
export const loginUser = createAsyncThunk(
  "auth/loginUser",
  async (credentials: { email: string; password: string }, { rejectWithValue }) => {
    try {
      const res = await apiClient.post("/login", credentials);
      return res.data;
    } catch (err: any) {
      return rejectWithValue(err.message);
    }
  }
);

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logout(state) {
      state.user = null;
      localData.remove("user");
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload;
        localData.add("user", action.payload); // ✅ persist to storage
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { logout } = authSlice.actions;
export default authSlice.reducer;
