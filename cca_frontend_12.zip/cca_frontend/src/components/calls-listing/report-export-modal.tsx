// src/components/ExportModal.tsx
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { XMarkIcon } from "@heroicons/react/24/outline";

interface Props {
    open: boolean;
    onClose: () => void;
}

export default function ExportModal({ open, onClose }: Props) {
    const [mode, setMode] = useState<"data" | "audio" | "both">("data");
    const [fileType, setFileType] = useState<"csv" | "json" | "zip">("csv");

    return (
        <AnimatePresence>
            {open && (
                <div className="fixed inset-0 z-50 flex items-center justify-center">
                    <motion.div className="absolute inset-0 bg-black/30" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
                    <motion.div className="bg-white w-full border border-gray-400 md:w-1/3 lg:w-2/5 rounded-md shadow z-10" initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}>
                        <div className=" flex items-center justify-between bg-(--primaryColor) text-white px-2 py-1 rounded-t-md">
                            <h3 className="text-lg font-medium">Export Data</h3>
                            <XMarkIcon onClick={() => onClose()} className="w-5 h-5 cursor-pointer " />
                        </div>
                        <div className=" p-5 text-sm">
                            <div className=" flex justify-between">
                                <div className="">
                                    <div className=" mb-2">Choose how you want to export Data:</div>
                                    <div className="flex gap-3">
                                        <label className="flex items-center gap-2"><input type="radio" checked={mode === "data"} onChange={() => setMode("data")} /> Data</label>
                                        <label className="flex items-center gap-2"><input type="radio" checked={mode === "audio"} onChange={() => setMode("audio")} /> Audio</label>
                                        <label className="flex items-center gap-2"><input type="radio" checked={mode === "both"} onChange={() => setMode("both")} /> Data & Audio</label>
                                    </div>
                                </div>

                                <div className="">
                                    <div className=" mb-2">File Type</div>
                                    <select value={fileType} onChange={(e) => setFileType(e.target.value as any)} className="border border-gray-400 rounded-full px-3 py-1">
                                        <option value="csv">CSV</option>
                                        <option value="json">JSON</option>
                                        <option value="zip">ZIP</option>
                                    </select>
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                <button className="px-3 py-1 bg-(--primaryColor) text-white rounded" onClick={() => { /* TODO: export */ onClose(); }}>Export</button>
                                <button className="px-3 py-1 border rounded" onClick={onClose}>Cancel</button>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
}
