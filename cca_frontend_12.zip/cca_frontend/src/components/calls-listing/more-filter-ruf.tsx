import { FunnelIcon, XMarkIcon } from "@heroicons/react/24/outline";
import { useState } from "react";
import SaveReportModal from "./save-report-modal";
import ExportModal from "./report-export-modal";

export interface Filters {
    agent: string;
    assignTo: string;
    dateFrom: string | null; // yyyy-mm-dd
    dateTo: string | null;
    duration: string; // e.g. "00:10"
    tags: string[];
    flagged: "" | "true" | "false";
}

interface Props {
    selectedIds: Set<string>;
    filters: Filters;
    onChange: (f: Filters) => void;
    onClear: () => void;
    onOpenSideFilter: () => void;
    onToggleAdvance: () => void;
    tagOptions: string[];
}

export default function FilterHeader({ selectedIds, filters, onChange, onClear, onOpenSideFilter, onToggleAdvance }: Props) {
    const selectedCount =
        (filters?.agent ? 1 : 0) +
        (filters?.assignTo ? 1 : 0) +
        (filters?.dateFrom || filters?.dateTo ? 1 : 0) +
        (filters?.duration ? 1 : 0) +
        (filters?.tags?.length ? filters?.tags?.length : 0) +
        (filters?.flagged ? 1 : 0);

    const [showSaveModal, setShowSaveModal] = useState(false);
    const [showExportModal, setShowExportModal] = useState(false);

    console.log("header filter--->>>", filters)

    return (
        <div className="flex items-start gap-3 justify-between w-full">
            <div className=" flex items-center flex-wrap gap-3">
                <select value={filters.agent} onChange={(e) => onChange({ ...filters, agent: e.target.value })} className="border border-gray-400 rounded px-2 py-1 text-sm bg-white">
                    <option value="">Agent</option>
                    <option value="Saurabh Tiwari">Saurabh Tiwari</option>
                    <option value="Harsh Pablo">Harsh Pablo</option>
                </select>

                <select value={filters.assignTo} onChange={(e) => onChange({ ...filters, assignTo: e.target.value })} className="border border-gray-400 rounded px-2 py-1 text-sm bg-white">
                    <option value="">Assign to</option>
                    <option value="Team A">Team A</option>
                    <option value="Team B">Team B</option>
                </select>

                <input type="date" value={filters.dateFrom ?? ""} onChange={(e) => onChange({ ...filters, dateFrom: e.target.value || null })} className="border border-gray-400 rounded px-2 py-1 text-sm bg-white" />
                <select value={filters.duration} onChange={(e) => onChange({ ...filters, duration: e.target.value })} className="border border-gray-400 rounded px-2 py-1 text-sm bg-white">
                    <option value="">Duration</option>
                    <option value="00:10">00:10</option>
                    <option value="00:30">00:30</option>
                    <option value="01:00">01:00</option>
                </select>

                {/* Tags simple compact select - opens full tag selection in side panel */}
                {/* <div className="relative">
        <select multiple value={filters.tags} onChange={(e) => onChange({ ...filters, tags: Array.from(e.target.selectedOptions).map(o => o.value) })} className="border rounded px-3 py-1 text-sm w-40">
          <option value="">Tags</option>
        </select>
      </div> */}
                <select value={filters.tags || ''} onChange={(e) => onChange({ ...filters, flagged: e.target.value as Filters["flagged"] })} className="border border-gray-400 rounded px-2 py-1 text-sm bg-white">
                    <option value="">Tags</option>
                    <option value="true">Flagged</option>
                    <option value="false">Not flagged</option>
                </select>

                <select value={filters.flagged} onChange={(e) => onChange({ ...filters, flagged: e.target.value as Filters["flagged"] })} className="border border-gray-400 rounded px-2 py-1 text-sm bg-white">
                    <option value="">Flagged</option>
                    <option value="true">Flagged</option>
                    <option value="false">Not flagged</option>
                </select>
            </div>

            <div className="">
                <div className=" flex items-center gap-2">
                    <div className="border rounded border-gray-400 bg-white flex items-center">
                        <button onClick={onOpenSideFilter} className=" flex items-center text-sm gap-1 px-1 py-1 ">
                            <FunnelIcon className="w-4 h-4" />
                            Filter
                            {selectedCount > 0 ?
                                <span className=" text-xs bg-gray-200 px-2 py-0.5 rounded-full">{selectedCount}</span>
                                :
                                <span className=" text-xs bg-gray-200 px-2 py-0.5 rounded-full">0</span>
                            }
                        </button>
                        {selectedCount > 0 && (
                            <button onClick={onClear} className=" hover:bg-gray-100 border-gray-400 border-l px-1 py-1">
                                <XMarkIcon className="w-5 h-5 text-gray-700" />
                            </button>
                        )}
                    </div>
                    <button onClick={onToggleAdvance} className="bg-(--primaryColor) text-white px-3 py-1 rounded text-sm whitespace-nowrap">Advance Search</button>
                </div>
                <div className=" flex items-center justify-end gap-2 mt-1">
                    {selectedIds.size === 0 ? (
                        <button
                            onClick={() => setShowSaveModal(true)}
                            className=" bg-(--primaryColor) text-white px-3 py-1 rounded text-sm"
                        >
                            Save as report
                        </button>
                    ) : (
                        <button
                            onClick={() => setShowExportModal(true)}
                            className="bg-emerald-600 text-white px-3 py-1 rounded text-sm"
                        >
                            Export ({selectedIds.size})
                        </button>
                    )}
                </div>
            </div>
            <SaveReportModal open={showSaveModal} onClose={() => setShowSaveModal(false)} />
            <ExportModal open={showExportModal} onClose={() => setShowExportModal(false)} />
        </div>
    );
}
