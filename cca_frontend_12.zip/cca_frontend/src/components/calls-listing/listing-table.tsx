import dayjs from "dayjs";
import type { CallRecord } from "../../api/dummy-data/calls-listing-data";
import { useEffect, useState } from "react";

interface Props {
    rows: CallRecord[];
    selectedIds: Set<string>;
    onSelect: (id: string, checked: boolean) => void;
    onSelectAll: (checked: boolean) => void;
    onToggleSort: () => void;
    setSelectedCall: any;
    selectedCall: any;
    sortAsc: boolean;
}

export default function CallsTable({ rows, selectedIds, onSelect, onSelectAll, setSelectedCall, selectedCall, onToggleSort, sortAsc }: Props) {
    const allSelected = rows.length > 0 && rows.every((r) => selectedIds.has(r.id));

    const [windowHeight, setWindowHeight] = useState(0);

    useEffect(() => {

        // This code will run only in the browser
        const updateWindowHeight = () => {
            // setWindowHeight(window?.innerHeight - 250)
            setWindowHeight(window?.innerHeight - (selectedCall ? 270 : 255))
        }

        // Set the initial window width
        updateWindowHeight()

        // Add event listener to track window resize
        window?.addEventListener('resize', updateWindowHeight)

        // Clean up the event listener when the component unmounts
        return () => {
            window?.removeEventListener('resize', updateWindowHeight)
        }
    }, [selectedCall])

    return (
        <div style={{ scrollbarWidth: "thin", height: windowHeight }} className="overflow-auto scrollbar-thin scrollbar-thumb-gray-900 scrollbar-track-gray-100 rounded-md border border-indigo-100">
            <table className="min-w-full text-sm ">
                <thead className="sticky top-0 z-10 bg-indigo-100 text-left">
                    <tr className=" border-b border-indigo-100">
                        <th className="p-2 text-center"><input type="checkbox" checked={allSelected} onChange={(e) => onSelectAll(e.target.checked)} /></th>
                        <th className="p-2">Agent</th>
                        <th className="p-2 cursor-pointer" onClick={onToggleSort}>Timestamp {sortAsc ? "▲" : "▼"}</th>
                        <th className="p-2 text-center">Duration</th>
                        <th className="p-2 text-center">Flagged</th>
                        <th className="p-2">Tag</th>
                    </tr>
                </thead>

                <tbody>
                    {rows?.length === 0 && (
                        <tr><td colSpan={5} className="p-6 text-center text-gray-500">No records</td></tr>
                    )}
                    {rows?.map((r) => (
                        <tr onClick={(r) => setSelectedCall(r)} key={r?.id} className=" bg-white border-b border-indigo-100">
                            <td className="p-2 text-center">
                                <input
                                    className=" cursor-pointer"
                                    type="checkbox"
                                    onClick={(e) => e.stopPropagation()}
                                    checked={selectedIds?.has(r?.id)}
                                    onChange={(e) => onSelect(r?.id, e.target.checked)} />
                            </td>
                            {selectedCall ?
                                <td className="p-2">
                                    <div className="font-medium">{r?.agent}</div>
                                    <div className="text-xs text-gray-500">{r?.note || "No Message Left"}</div>
                                </td>
                                :
                                <td className="p-2 flex items-center gap-1">
                                    <div className="font-medium">{r?.agent}</div> |
                                    <div className="text-xs text-gray-500">{r?.note || "No Message Left"}</div>
                                </td>
                            }
                            <td className="p-2">{dayjs(r?.timestamp).format("DD/MM/YYYY @ hh:mm A")}</td>
                            <td className="p-2 text-center">{r?.duration}</td>
                            <td className="p-2 text-center">
                                {r?.flagged ? <span className="text-red-600">🚩</span> : "-"}
                            </td>
                            <td className="p-2">
                                <div className=" flex flex-wrap gap-1">
                                    {r?.tags.map((t) => <span key={t} style={{ fontSize: '10px' }} className=" bg-red-100 border border-red-600 text-red-600 px-2 py-0.5 rounded-full">{t}</span>)}
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
