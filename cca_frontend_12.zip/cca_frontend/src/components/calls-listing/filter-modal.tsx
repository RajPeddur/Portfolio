import React, { useMemo, useState } from "react";
import {
    QueryBuilder,
    type RuleGroupType,
    type Field,
    type ValueEditorProps,
} from "react-querybuilder";
import { AnimatePresence, motion } from "framer-motion";
import { XMarkIcon, PlusIcon, TrashIcon } from "@heroicons/react/24/outline";
import toast from "react-hot-toast";

const fields: Field[] = [
    { name: "collectorName", label: "Collector Name", valueEditorType: "text" },
    { name: "avgScore", label: "Average Score %", valueEditorType: "text" },
    { name: "scorecardSubmitted", label: "Scorecard Submitted", valueEditorType: "checkbox" },
    { name: "callsFailedPercent", label: "Calls Failed %", valueEditorType: "text" },
    { name: "totalScore", label: "Total Score", valueEditorType: "text" },
];

const operatorConfig: Record<string, { name: string; label: string }[]> = {
    string: [
        { name: "=", label: "is" },
        { name: "!=", label: "is not" },
        { name: "contains", label: "contains" },
        { name: "beginsWith", label: "begins with" },
        { name: "endsWith", label: "ends with" },
        { name: "doesNotContain", label: "does not contain" },
        { name: "null", label: "is null" },
        { name: "notNull", label: "is not null" },
        { name: "in", label: "in list" },
        { name: "notIn", label: "not in list" },
    ],
    number: [
        { name: "=", label: "equals" },
        { name: "!=", label: "not equal" },
        { name: "<", label: "less than" },
        { name: "<=", label: "less than or equal" },
        { name: ">", label: "greater than" },
        { name: ">=", label: "greater than or equal" },
        { name: "between", label: "between" },
        { name: "notBetween", label: "not between" },
        { name: "in", label: "in list" },
        { name: "notIn", label: "not in list" },
        { name: "null", label: "is null" },
        { name: "notNull", label: "is not null" },
    ],
    boolean: [{ name: "=", label: "equals" }],
};

interface SideFilterPanelProps {
    open?: boolean;
    initial?: Record<string, any>;
    onClose?: () => void;
    onApply: (vals: any) => void;
}

const dropdownClass =
    "border border-gray-400 rounded-md text-sm px-2 py-[2px] bg-white focus:ring-2 focus:ring-blue-400";

const buttonClass =
    "rounded-md text-sm font-medium transition-colors duration-150";

const CustomValueEditor: React.FC<ValueEditorProps> = ({
    field,
    value,
    handleOnChange,
}) => {
    const selectedField = fields.find((f) => f.name === field);
    if (selectedField?.valueEditorType === "checkbox") {
        return (
            <label className="flex items-center gap-2 text-sm text-gray-700 w-40">
                <input
                    type="checkbox"
                    checked={!!value}
                    onChange={(e) => handleOnChange(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-400 focus:ring-2 focus:ring-blue-400"
                />
                <span>True</span>
            </label>
        );
    }

    const inputType =
        ["avgScore", "callsFailedPercent", "totalScore"].includes(selectedField?.name ?? "")
            ? "number"
            : "text";

    return (
        <input
            type={inputType}
            value={value ?? ""}
            onChange={(e) => handleOnChange(e.target.value)}
            className={`${dropdownClass} w-40`}
            placeholder="Enter value"
        />
    );
};

const CustomFieldSelector = ({ options, value, handleOnChange }: any) => (
    <select
        value={value ?? ""}
        onChange={(e) => handleOnChange(e.target.value)}
        className={`${dropdownClass} w-40`}
    >
        <option value="">Select field</option>
        {options.map((opt: any) => (
            <option key={opt.name} value={opt.name}>
                {opt.label}
            </option>
        ))}
    </select>
);

const CustomOperatorSelector = ({ options, value, handleOnChange }: any) => (
    <select
        value={value ?? ""}
        onChange={(e) => handleOnChange(e.target.value)}
        className={`${dropdownClass} w-36`}
    >
        <option value="">Select</option>
        {options.map((opt: any) => (
            <option key={opt.name} value={opt.name}>
                {opt.label}
            </option>
        ))}
    </select>
);

const SideFilterPanel: React.FC<SideFilterPanelProps> = ({
    onClose,
    onApply,
    initial,
}) => {

    const [errorMsg, setErrorMsg] = useState(false)

    const createEmptyRule = () => ({
        id: crypto.randomUUID?.() ?? Math.random().toString(36).substring(2),
        field: "",
        operator: "",
        value: "",
    });

    // start with either initial rules (if provided) OR a single empty row (without added flag)
    const [query, setQuery] = useState<RuleGroupType>(
        initial && initial.rules?.length
            ? (initial as RuleGroupType)
            : { combinator: "and", rules: [createEmptyRule()] }
    );

    const operatorsByField = useMemo(() => {
        const map: Record<string, { name: string; label: string }[]> = {};
        fields.forEach((f) => {
            let type: "string" | "number" | "boolean" = "string";
            if (["avgScore", "callsFailedPercent", "totalScore"].includes(f.name)) {
                type = "number";
            } else if (f.valueEditorType === "checkbox") {
                type = "boolean";
            }
            map[f.name] = operatorConfig[type];
        });
        return map;
    }, []);

    // helper to detect if a rule is "filled" (has meaningful data)
    const isRuleFilled = (r: any) =>
        r && typeof r.field === "string" && r.field.trim() !== "" &&
        r.operator && (r.value !== undefined && String(r.value).trim() !== "");

    // MAIN: add rule behavior:
    // - only allow add if last rule is filled OR there are no rules
    // - when adding, mark the *previous* last rule as added: true (so it becomes removable)
    // - append a new empty row WITHOUT added flag
    const handleAddRule = () => {
        const lastRule: any = query.rules[query.rules.length - 1];

        const lastIsFilled = isRuleFilled(lastRule);

        if (!lastRule || lastIsFilled || query.rules.length === 0) {
            setQuery((prev) => {
                // map previous last to added:true if it exists and is filled
                const newRules = prev.rules.map((r, i) =>
                    i === prev.rules.length - 1 && isRuleFilled(prev.rules[prev.rules.length - 1])
                        ? { ...r, added: true }
                        : r
                );
                return {
                    ...prev,
                    rules: [
                        ...newRules,
                        { field: "", operator: "", value: "" }, // new empty row (no added)
                    ],
                };
            });
            setErrorMsg(false)
        } else {
            setErrorMsg(true)
        }
    };

    // remove rule (we rely on the QueryBuilder's props.handleOnClick to remove)
    // show trash only for rules that have `added === true`
    const handleApply = () => {
        const cleaned = {
            ...query,
            rules: query?.rules?.filter((r: any) => isRuleFilled(r)),
        };
        if (!cleaned?.rules?.length) {
            toast.error("Please add filter.");
            return;
        }
        onApply(cleaned);
        console.log("cleaned----->>>>", cleaned?.rules)
    };

    const handleClear = () => {
        setQuery({
            combinator: "and",
            rules: [createEmptyRule()], // ✅ always keep one empty row
        });
    };

    return (
        <div className="hidden md:block absolute right-4 mt-8 z-40">
            <AnimatePresence>
                <motion.div
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    className="w-full bg-white border border-gray-400 rounded-lg shadow-md p-3"
                >
                    <div className="flex items-start justify-between mb-2">
                        <QueryBuilder
                            fields={fields}
                            query={query}
                            onQueryChange={setQuery}
                            getOperators={(fieldName) => (fieldName ? operatorsByField[fieldName] : [])}
                            controlElements={{
                                valueEditor: CustomValueEditor,
                                fieldSelector: CustomFieldSelector,
                                operatorSelector: CustomOperatorSelector,
                                combinatorSelector: () => null,
                                addGroupAction: () => null,
                                // replace addRuleAction to call our validated handleAddRule
                                addRuleAction: () => (
                                    <button
                                        type="button"
                                        onClick={handleAddRule}
                                        className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                                    >
                                        + Add Filter
                                    </button>
                                ),
                                removeRuleAction: (props: any) => {
                                    // only allow removing rules that were marked as 'added'
                                    const rule: any = props.rule;
                                    if (rule && rule.added === true) {
                                        return (
                                            <button
                                                onClick={props.handleOnClick}
                                                className="p-1 rounded hover:bg-gray-100"
                                                title="Remove filter"
                                            >
                                                <TrashIcon className="w-4 h-4 text-gray-500" />
                                            </button>
                                        );
                                    }
                                    return <div className="w-6" />;
                                },
                            }}
                        />
                        <button onClick={onClose} className="p-1 rounded hover:bg-gray-100 transition">
                            <XMarkIcon className="w-5 h-5 text-gray-500" />
                        </button>
                    </div>
                    {errorMsg &&
                    <span className=" text-red-500 text-xs">Please fill the current filter before adding another.</span>
                    }

                    <div className="border-t border-gray-400 mt-3 pt-3 flex justify-between items-center">
                        <button
                            onClick={handleAddRule}
                            className={`${buttonClass} flex items-center gap-1 text-gray-700 hover:text-gray-900`}
                        >
                            <PlusIcon className="w-4 h-4" />
                            Add Filter
                        </button>

                        <div className="flex gap-2">
                            <button
                                onClick={handleApply}
                                className={`${buttonClass} border border-gray-400 bg-gray-200 hover:bg-gray-400 px-3 py-1.5`}
                            >
                                Apply Filter
                            </button>
                            <button
                                onClick={handleClear}
                                className={`${buttonClass} border border-gray-400 hover:bg-gray-100 px-3 py-1.5 text-gray-700`}
                            >
                                Clear all
                            </button>
                        </div>
                    </div>
                </motion.div>
            </AnimatePresence>
        </div>
    );
};

export default SideFilterPanel;
