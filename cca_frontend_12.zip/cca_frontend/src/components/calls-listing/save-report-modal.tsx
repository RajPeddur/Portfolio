// src/components/SaveReportModal.tsx
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { XMarkIcon } from "@heroicons/react/24/outline";

interface Props {
    open: boolean;
    onClose: () => void;
}

export default function SaveReportModal({ open, onClose }: Props) {
    const [name, setName] = useState("");
    const [schedule, setSchedule] = useState(false);
    const [frequency, setFrequency] = useState("");
    const [visibility, setVisibility] = useState<"Private" | "Public" | "Only You">("Private");

    return (
        <AnimatePresence>
            {open && (
                <div className="fixed inset-0 z-50 flex items-center justify-center">
                    <motion.div className="absolute inset-0 bg-black/30" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
                    <motion.div className="bg-white w-full border border-gray-400 md:w-1/3 lg:w-2/5 rounded-md shadow-lg z-10" initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}>
                        <div className=" flex items-center justify-between bg-(--primaryColor) text-white px-2 py-1 rounded-t-md">
                            <h3 className="text-lg font-medium">Report Data</h3>
                            <XMarkIcon onClick={() => onClose()} className="w-5 h-5 cursor-pointer " />
                        </div>
                        <div className=" p-5 text-sm">
                            <label>Report Name</label>
                            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Report Name" className="w-full border border-gray-400 rounded-md px-3 py-1 mb-3" />
                            <div className="flex items-start justify-between mb-3">
                                <label className="flex items-center gap-2">
                                    <input type="checkbox" checked={schedule} onChange={(e) => setSchedule(e.target.checked)} />
                                    Do you want to schedule
                                </label>
                                <label className="flex items-center gap-2">
                                    <input type="checkbox" checked={schedule} onChange={(e) => setSchedule(e.target.checked)} />
                                    <div className=" leading-3">
                                        <h1>Quick link</h1>
                                        <span style={{ fontSize: '10px'}} className=" text-gray-500">Shown in dashboard page for quick access</span>
                                    </div>
                                </label>
                            </div>
                            {schedule && (
                                <div className="mb-3">
                                    <label className=" mr-3">Frequency:</label>
                                    <select value={frequency} onChange={(e) => setFrequency(e.target.value)} className=" border border-gray-400 rounded-lg px-3 py-1">
                                        <option value="">Select frequency</option>
                                        <option value="daily">Daily</option>
                                        <option value="weekly">Weekly</option>
                                    </select>
                                </div>
                            )}
                            <div className="mb-3">
                                <div className="text-sm mb-2">Choose who can view this report</div>
                                <div className="flex gap-3">
                                    <label className="flex items-center gap-2"><input type="radio" name="vis" checked={visibility === "Private"} onChange={() => setVisibility("Private")} /> Private</label>
                                    <label className="flex items-center gap-2"><input type="radio" name="vis" checked={visibility === "Public"} onChange={() => setVisibility("Public")} /> Public</label>
                                    <label className="flex items-center gap-2"><input type="radio" name="vis" checked={visibility === "Only You"} onChange={() => setVisibility("Only You")} /> Only You</label>
                                </div>
                            </div>

                            <div className="flex items-center gap-2">
                                <button className="px-3 py-1 bg-blue-900 border border-blue-900 text-white rounded" onClick={() => { /* TODO: save */ onClose(); }}>Save</button>
                                <button className="px-3 py-1 border rounded" onClick={onClose}>Cancel</button>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
}
