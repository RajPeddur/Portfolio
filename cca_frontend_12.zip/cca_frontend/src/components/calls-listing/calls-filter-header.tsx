import { FunnelIcon, XMarkIcon } from "@heroicons/react/24/outline";
import { useState, useEffect, useMemo } from "react";
import SaveReportModal from "./save-report-modal";
import ExportModal from "./report-export-modal";
import SideFilterPanel from "./filter-modal";

export interface Filters {
    agent: string;
    assignTo: string;
    dateFrom: string | null;
    dateTo: string | null;
    duration: string;
    tags: string[];
    flagged: "" | "true" | "false";
}

interface Rule {
    field: string;
    operator: string;
    value: string;
}

interface RuleGroup {
    rules: Rule[];
}

interface Props {
    selectedIds: Set<string>;
    filters: Filters;
    onChange: (f: Filters) => void;
    onClear: () => void;
    onOpenSideFilter: () => void;
    onToggleAdvance: () => void;
    tagOptions: string[];
}

export default function FilterHeader({
    selectedIds,
    filters,
    onChange,
    onClear,
    onToggleAdvance,
}: Props) {
    const [showSaveModal, setShowSaveModal] = useState(false);
    const [showExportModal, setShowExportModal] = useState(false);
    const [showSideFilter, setShowSideFilter] = useState(false);
    const [sideFilterData, setSideFilterData] = useState<RuleGroup>({ rules: [] });

    console.log("sideFilterData---->>>", sideFilterData)

    // ✅ Convert Filters → RuleGroup when filters change
    useEffect(() => {
        const rules: Rule[] = Object.entries(filters)
            .filter(([_, value]) => value && value !== "" && value !== null)
            .map(([key, value]) => ({
                field: key,
                operator: "=",
                value: Array.isArray(value) ? value.join(", ") : String(value),
            }));
        setSideFilterData({ rules });
    }, [filters]);

    // ✅ Convert RuleGroup → Filters when applying from SideFilterPanel
    const handleApplyFromSide = (vals: RuleGroup) => {
        const updated: Filters = {
            agent: "",
            assignTo: "",
            dateFrom: null,
            dateTo: null,
            duration: "",
            tags: [],
            flagged: "",
        };

        vals.rules.forEach((r) => {
            if (r.field in updated) {
                (updated as any)[r.field] = r.value;
            }
        });

        console.log("vals----->>>", vals)

        onChange(updated);
        setSideFilterData(vals);
        setShowSideFilter(false);
    };

    // ✅ Dynamically compute how many active filters exist
    const activeFilterCount = useMemo(() => sideFilterData.rules.length, [sideFilterData]);

    return (
        <div className="flex items-start gap-3 justify-between w-full">
            <div className="flex items-center flex-wrap gap-3">
                {/* --- Simple Filters --- */}
                <select
                    value={filters.agent}
                    onChange={(e) => onChange({ ...filters, agent: e.target.value })}
                    className="border border-gray-400 rounded px-2 py-1 text-sm bg-white"
                >
                    <option value="">Agent</option>
                    <option value="Saurabh Tiwari">Saurabh Tiwari</option>
                    <option value="Harsh Pablo">Harsh Pablo</option>
                </select>

                <select
                    value={filters.assignTo}
                    onChange={(e) => onChange({ ...filters, assignTo: e.target.value })}
                    className="border border-gray-400 rounded px-2 py-1 text-sm bg-white"
                >
                    <option value="">Assign to</option>
                    <option value="Team A">Team A</option>
                    <option value="Team B">Team B</option>
                </select>

                <input
                    type="date"
                    value={filters.dateFrom ?? ""}
                    onChange={(e) => onChange({ ...filters, dateFrom: e.target.value || null })}
                    className="border border-gray-400 rounded px-2 py-1 text-sm bg-white"
                />

                <select
                    value={filters.duration}
                    onChange={(e) => onChange({ ...filters, duration: e.target.value })}
                    className="border border-gray-400 rounded px-2 py-1 text-sm bg-white"
                >
                    <option value="">Duration</option>
                    <option value="00:10">00:10</option>
                    <option value="00:30">00:30</option>
                    <option value="01:00">01:00</option>
                </select>

                <select
                    value={filters.flagged}
                    onChange={(e) =>
                        onChange({ ...filters, flagged: e.target.value as Filters["flagged"] })
                    }
                    className="border border-gray-400 rounded px-2 py-1 text-sm bg-white"
                >
                    <option value="">Flagged</option>
                    <option value="true">Flagged</option>
                    <option value="false">Not flagged</option>
                </select>

                {/* --- Filter Button --- */}
                <div className="border rounded border-gray-400 bg-white flex items-center">
                    <button
                        onClick={() => setShowSideFilter(true)}
                        className="flex items-center text-sm gap-1 px-1 py-1"
                    >
                        <FunnelIcon className="w-4 h-4" />
                        Filter
                        <span className="text-xs bg-gray-200 px-2 py-0.5 rounded-full">
                            {activeFilterCount}
                        </span>
                    </button>
                    {activeFilterCount > 0 && (
                        <button
                            onClick={onClear}
                            className="hover:bg-gray-100 border-gray-400 border-l px-1 py-1"
                        >
                            <XMarkIcon className="w-5 h-5 text-gray-700" />
                        </button>
                    )}
                </div>

                {/* --- Advance Search Button --- */}
                <button
                    onClick={onToggleAdvance}
                    className="bg-(--primaryColor) text-white px-3 py-1 rounded text-sm whitespace-nowrap"
                >
                    Advance Search
                </button>
            </div>

            {/* --- Right Buttons --- */}
            <div className="flex flex-col items-end">
                <div className="flex items-center justify-end gap-2 mt-1">
                    {selectedIds.size === 0 ? (
                        <button
                            onClick={() => setShowSaveModal(true)}
                            className="bg-(--primaryColor) text-white px-3 py-1 rounded text-sm"
                        >
                            Save as report
                        </button>
                    ) : (
                        <button
                            onClick={() => setShowExportModal(true)}
                            className="bg-emerald-600 text-white px-3 py-1 rounded text-sm"
                        >
                            Export ({selectedIds.size})
                        </button>
                    )}
                </div>
            </div>

            {/* --- Modals --- */}
            <SaveReportModal open={showSaveModal} onClose={() => setShowSaveModal(false)} />
            <ExportModal open={showExportModal} onClose={() => setShowExportModal(false)} />

            {/* --- Side Filter Panel (connected) --- */}
            {showSideFilter &&
                <SideFilterPanel
                    initial={sideFilterData}
                    onApply={handleApplyFromSide}
                    onClose={() => setShowSideFilter(false)}
                    open={false}
                />
            }
        </div>
    );
}
