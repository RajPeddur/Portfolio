// src/components/AdvanceSearchDropdown.tsx
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { XMarkIcon } from "@heroicons/react/24/outline";

interface Props {
    onApply: (vals: { keyword?: string; speaker?: string }) => void;
    onClose: () => void;
}

export default function AdvanceSearchDropdown({ onApply, onClose }: Props) {
    const [keyword, setKeyword] = useState("");
    const [speaker, setSpeaker] = useState("Agent");

    return (
        <>
            {/* Desktop anchored dropdown */}
            <div className="hidden md:block absolute right-4 mt-3 z-40">
                <AnimatePresence>
                    <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="w-80 bg-white border border-gray-400 rounded-md shadow p-3">
                        <div className=" flex items-center gap-2 mb-2">
                            <input className="w-full border border-gray-400 rounded px-2 py-0.5" placeholder="Search or type keyword" value={keyword} onChange={(e) => setKeyword(e.target.value)} />
                            <button onClick={() => onClose()} className=" hover:bg-gray-100 border-gray-400 px-1 py-1">
                                <XMarkIcon className="w-5 h-5 text-gray-700" />
                            </button>
                        </div>
                        <div className=" flex justify-between items-center">
                            <select className=" border border-gray-400 rounded px-2 py-1" value={speaker} onChange={(e) => setSpeaker(e.target.value)}>
                                <option>Agent</option>
                                <option>Customer</option>
                                <option>Both</option>
                            </select>
                            <div className="flex items-center gap-2">
                                <button className="px-3 py-0.5 border border-gray-400 rounded" onClick={() => { setKeyword(""); setSpeaker("Agent"); }}>Clear</button>
                                <button className="px-3 py-0.5 border border-blue-900 bg-blue-900 text-white rounded" onClick={() => { onApply({ keyword, speaker }); }}>Search</button>
                            </div>
                        </div>
                    </motion.div>
                </AnimatePresence>
            </div>

            {/* Mobile bottom sheet */}
            <div className="md:hidden fixed left-0 right-0 bottom-0 z-50">
                <div className="bg-white border-t border-gray-400 shadow-lg p-3">
                    <input className="w-full border border-gray-400 rounded px-2 py-1 mb-2" placeholder="Search or type keyword" value={keyword} onChange={(e) => setKeyword(e.target.value)} />
                    <select className="w-full border border-gray-400 rounded px-2 py-1 mb-3" value={speaker} onChange={(e) => setSpeaker(e.target.value)}>
                        <option>Agent</option>
                        <option>Customer</option>
                        <option>Both</option>
                    </select>
                    <div className="flex justify-between">
                        <button className="px-3 py-1 border border-gray-400 rounded" onClick={() => onClose()}>Close</button>
                        <div className="flex gap-2">
                            <button className="px-3 py-1 border border-gray-400 rounded" onClick={() => { setKeyword(""); setSpeaker("Agent"); }}>Clear</button>
                            <button className="px-3 py-1 bg-blue-600 text-white rounded" onClick={() => { onApply({ keyword, speaker }); }}>Search</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
