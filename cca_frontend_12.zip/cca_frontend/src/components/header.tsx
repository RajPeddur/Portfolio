import { BellIcon } from "@heroicons/react/16/solid";
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

const Header = () => {
  
  const [openLogOut, setOpenLogOut] = useState(false);

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/");
    toast.success("Logout.")
  };

  const logOutFun = () => {
    openLogOut ? setOpenLogOut(false) : setOpenLogOut(true)
  }

  let logOutRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let logOutFun = (event: any) => {
      if (!logOutRef.current?.contains(event.target)) {
        setOpenLogOut(false)
      }
    };

    document.addEventListener('mousedown', logOutFun)

  }, [])

  return (
    <header className="flex items-center justify-between bg-gray-800 text-gray-200 px-4 py-3 border-b border-gray-200 dark:border-gray-700">
      <h2 className=" text-lg font-semibold ml-2 pb-1 border-b-2 border-(--primaryColor)">
        Dashboard
      </h2>
      <div className="flex items-center gap-4">
        <div className="relative inline-block" ref={logOutRef}>
          <div onClick={() => logOutFun()} className="flex items-center gap-2 cursor-pointer">
            <span className="text-sm font-medium">Hi, Shradha</span>
            <div className="w-8 h-8 bg-(--primaryColor) flex items-center justify-center rounded-full text-sm font-semibold">
              SP
            </div>
          </div>
          {openLogOut ?
            <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-300 text-gray-800 rounded-lg shadow-lg py-2 px-3 z-20">
              <div className=" flex justify-between items-center">
                <span className=" text-sm font-semibold">Personal</span>
                <button className=" text-sm cursor-pointer hover:text-indigo-600 hover:underline" onClick={handleLogout}>Logout</button>
              </div>
              <div className={` mt-2 flex items-center gap-2 dark:bg-gray-800 py-1.5 border-gray-300`}>
                <div className="w-10 h-10 bg-(--primaryColor) flex items-center justify-center rounded-full text-sm font-semibold text-white">
                  SP
                </div>
                <div className=" flex flex-col justify-center">
                  <div className=' text-sm font-semibold'>Shradha</div>
                  <span className=" text-xs text-gray-500">admin@cca.com</span>
                </div>
              </div>
            </div>
            : ""}
        </div>
        <button className=" relative">
          <span className="absolute top-0 right-0 h-2 w-2 mt-0.5 mr-1 bg-red-500 rounded-full"></span>
          <span className="absolute top-0 right-0 h-2 w-2 mt-0.5 mr-1 bg-red-500 rounded-full animate-ping"></span>
          <BellIcon className=" w-7 h-7" />
        </button>
      </div>
    </header>
  );
};

export default Header;
