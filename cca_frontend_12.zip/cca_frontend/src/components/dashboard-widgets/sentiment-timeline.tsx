import React, { useMemo, useState, useEffect, useRef } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface SentimentData {
  date: string;
  rating: number;
  details: string;
}

interface SentimentTimelineProps {
  startDate: string; // now expects dd-mm-yyyy
  endDate: string;   // now expects dd-mm-yyyy
}

// ✅ Custom tooltip for chart hover
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const item = payload[0].payload;
    return (
      <div className="bg-white shadow-md p-2 border rounded-md text-sm">
        <p className="font-semibold">{label}</p>
        <p>Rating: {item.rating}</p>
        <p>{item.details}</p>
      </div>
    );
  }
  return null;
};

// ✅ Parse dd-mm-yyyy → valid Date object
const parseDate = (dateStr: string): Date => {
  const [day, month, year] = dateStr.split("-").map(Number);
  return new Date(year, month - 1, day);
};

// ✅ Safe local date formatter for chart display (short labels)
const formatDate = (dateString: string) => {
  const [day, month, year] = dateString.split("-").map(Number);
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
};

// ✅ Helper to calculate total days (inclusive)
const calculateDaysBetween = (start: string, end: string): number => {
  const startDate = parseDate(start);
  const endDate = parseDate(end);
  const diffDays = Math.floor(
    (endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)
  );
  return diffDays + 1;
};

// ✅ Generate mock data for the exact date range
const generateMockData = (startDate: string, endDate: string): SentimentData[] => {
  const data: SentimentData[] = [];
  const totalDays = calculateDaysBetween(startDate, endDate);
  const start = parseDate(startDate);

  for (let i = 0; i < totalDays; i++) {
    const date = new Date(start);
    date.setDate(start.getDate() + i);

    const formattedDate = date
      .toLocaleDateString("en-GB") // gives DD/MM/YYYY
      .replace(/\//g, "-");        // convert to DD-MM-YYYY

    data.push({
      date: formattedDate,
      rating: Math.floor(Math.random() * 10),
      details: `This is sentiment detail for ${date.toDateString()}`,
    });
  }

  return data;
};

const SentimentTimeline: React.FC<SentimentTimelineProps> = ({
  startDate,
  endDate,
}) => {
  const [data, setData] = useState<SentimentData[]>([]);

  useEffect(() => {
    if (startDate && endDate) {
      const mockData = generateMockData(startDate, endDate);
      setData(mockData);
    }
  }, [startDate, endDate]);

  // ✅ Prepare data for chart
  const processedData = useMemo(
    () =>
      data.map((d) => ({
        ...d,
        formattedDate: formatDate(d.date),
      })),
    [data]
  );

  // ✅ Dynamically calculate X-axis tick spacing
  const visibleTicks = useMemo(() => {
    if (!processedData.length) return [];
    const step = Math.ceil(processedData.length / 6);
    return processedData
      .filter((_, index) => index % step === 0)
      .map((d) => d.formattedDate);
  }, [processedData]);

  // below code use for manage width with collapse on side bar menu
  const useResizeObserver = (callback: any) => {
    const ref = useRef(null);
    useEffect(() => {
      const observer = new ResizeObserver(callback);
      if (ref.current) observer.observe(ref.current);
      return () => observer.disconnect();
    }, [callback]);
    return ref;
  };

  const containerRef = useResizeObserver(() => {
    window.dispatchEvent(new Event("resize"));
  });

  return (
    <div ref={containerRef} className="border border-gray-300 shadow-md rounded-md p-4 bg-white">
      <h2 className="text-lg font-semibold mb-3">Sentiment Timeline</h2>

      <ResponsiveContainer width="100%" height={250}>
        <LineChart
          data={processedData}
          margin={{ top: 20, right: 30, bottom: 20, left: 0 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="formattedDate"
            ticks={visibleTicks}
            tick={{ fontSize: 12 }}
            interval={0}
            label={{
              value: "Days",
              position: "insideBottom",
              offset: -5,
              style: { textAnchor: "middle", fontSize: 14 },
            }}
          />
          <YAxis
            domain={[0, "dataMax + 2"]}
            label={{
              value: "Ratings",
              angle: -90,
              position: "insideLeft",
              style: { textAnchor: "middle", fontSize: 14 },
            }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Line
            type="monotone"
            dataKey="rating"
            stroke="#d13838"
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default SentimentTimeline;
