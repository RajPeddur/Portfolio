import { useGetAgentLeaderboardQuery } from "../../services/agent-leaderboard-api";

interface ServiceBarChartProps {
    startDate: string;
    endDate: string;
}

const AgentLeaderBoardTable: React.FC<ServiceBarChartProps> = ({
    startDate,
    endDate,
}) => {
    const { data, isLoading, isError } = useGetAgentLeaderboardQuery({
        startDate: startDate,
        endDate: endDate,
    });

    if (isLoading) return <div className="text-gray-500 text-center py-6">Loading...</div>;
    if (isError) return <div className="text-red-500 text-center py-6">Error loading chart</div>;

    const records = data?.data?.records || [];

    return (
        <div className="border border-gray-300 shadow-md rounded-md p-2 bg-white">
            <h2 className="text-lg font-semibold mb-1">Agent Leaderboard</h2>
            <div style={{ scrollbarWidth: "thin", height: 168 }} className=" border border-gray-200 rounded-sm overflow-auto scrollbar-thin scrollbar-thumb-gray-900 scrollbar-track-gray-100">
                {records?.length > 0 ? (
                    <table className="w-full text-sm text-left sticky top-0">
                        <thead className=" bg-pink-100 font-semibold sticky top-0 z-10 border-b border-gray-200">
                            <tr>
                                <th className="py-2 px-4 text-center">Rank</th>
                                <th className="py-2 px-4 ">Agent</th>
                                <th className="py-2 px-4 text-center">Total Calls</th>
                                <th className="py-2 px-4 text-center">QA Score</th>
                            </tr>
                        </thead>
                        <tbody >
                            {records?.map((item, index) => (
                                <tr key={index} className=" odd:bg-white even:bg-gray-100">
                                    <td className="py-1 px-4 text-center">{item?.rank}</td>
                                    <td className="py-1 px-4 ">{item?.agent}</td>
                                    <td className="py-1 px-4 text-center">{item?.totalCall}</td>
                                    <td className="py-1 px-4 text-center">{item?.qaScore}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                ) : (
                    <div className="flex flex-col gap-3 items-center justify-center text-center project-text-gray">
                        <img className="h-36 w-64 " src="/static/images/dataEmpty.png" alt="data empty" />
                        <div style={{ fontSize: '16px' }} className="xl:py-4 lg:py-3 md:py-2 sm:py-1 px-5">
                            Commission not get displayed basis filter applied.
                        </div>
                    </div>
                )}
            </div>
        </div>
    )
}

export default AgentLeaderBoardTable;