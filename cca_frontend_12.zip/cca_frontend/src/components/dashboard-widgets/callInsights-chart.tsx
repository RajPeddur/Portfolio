import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LabelList,
} from "recharts";
import { useGetCallInsightsQuery } from "../../services/call-insights-api";

interface CallInsightsBarChartProps {
    startDate: string;
    endDate: string;
}

const CallInsightsChart: React.FC<CallInsightsBarChartProps> = ({
    startDate,
    endDate,
}) => {
  const { data, isLoading, isError } = useGetCallInsightsQuery({
    startDate: startDate,
    endDate: endDate,
  });

  const records = data?.data?.records || [];

  if (isLoading) return <div className="p-4">Loading...</div>;
  if (isError) return <div className="p-4 text-red-500">Failed to load data.</div>;
  if (!data || records?.length === 0) return <div className="p-4">No data available.</div>;

  return (
    <div className="border border-gray-300 shadow-md rounded-md p-4 bg-white">
      <h2 className="text-lg font-semibold mb-4">Call Insights</h2>

      <div style={{ scrollbarWidth: "thin", scrollbarColor: "#C26C63 transparent" }} className="h-[245px] overflow-y-auto scrollbar-thin scrollbar-track-transparent pr-2">
        <ResponsiveContainer width="100%" height={records?.length * 28}>
          <BarChart
            layout="vertical"
            data={records}
            margin={{ top: 10, right: 30, left: 0, bottom: 10 }}
            barCategoryGap={6} // ↓ Reduced gap between bars
          >
            <XAxis type="number" hide />
            <YAxis
              dataKey="label"
              type="category"
              width={180}
              tick={{ fontSize: 12 }}
              tickLine={true}
              axisLine={true}
            />

            <Tooltip
              cursor={{ fill: "rgba(0,0,0,0.05)" }}
              content={({ payload }) => {
                if (payload && payload?.length) {
                  const item = payload[0]?.payload;
                  return (
                    <div className="bg-white border border-gray-200 rounded-md shadow-md p-2 text-xs">
                      <p className="font-semibold">{item?.label}</p>
                      <p>Calls: {item?.calls}</p>
                    </div>
                  );
                }
                return null;
              }}
            />

            <Bar dataKey="calls" fill="#C26C63" barSize={12}>
              <LabelList
                dataKey="calls"
                position="right"
                fill="#333"
                fontSize={12}
                formatter={(value: any) =>
                  typeof value === "number" ? value?.toLocaleString() : value ?? ""
                }
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default CallInsightsChart;
