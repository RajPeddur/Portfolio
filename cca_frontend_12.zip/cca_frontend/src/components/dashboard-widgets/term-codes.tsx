import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  Label,
} from "recharts";
import { useGetTermCodesQuery } from "../../services/term-codes-api";

interface TermCodesBarChartProps {
  startDate: string;
  endDate: string;
}

const TermCodesChart: React.FC<TermCodesBarChartProps> = ({
  startDate,
  endDate,
}) => {
  const { data, isLoading, isError } = useGetTermCodesQuery({
    startDate: startDate,
    endDate: endDate,
  });

  const records = data?.data?.records || [];

  const colors = [
    "#A3CEF1",
    "#82B1D1",
    "#6A9FB5",
    "#4E89A9",
    "#367C99",
    "#2E6F91",
    "#1E5F82",
    "#0E4F72",
    "#003F63",
  ];

  if (isLoading) return <div className="p-4">Loading...</div>;
  if (isError) return <div className="p-4 text-red-500">Failed to load data.</div>;
  if (!data || records?.length === 0) return <div className="p-4">No data available.</div>;

  return (
    <div className="border border-gray-300 shadow-md rounded-md p-4 bg-white">
      <h2 className="text-lg font-semibold mb-4">Term Codes</h2>
      <div style={{ scrollbarWidth: "thin", scrollbarColor: "#0E4F72 transparent" }} className="h-[155px] overflow-y-auto scrollbar-thin scrollbar-track-transparent pr-2">
        <ResponsiveContainer width="100%" height={records?.length * 39}>
          <BarChart
            layout="vertical"
            data={records}
            margin={{ top: 10, right: 30, left: 0, bottom: 10 }}
            barCategoryGap={6}
          >
            <XAxis type="number" tick={{ fontSize: 12 }}>
              <Label
                value="No. of Calls"
                offset={-5}
                position="bottom"
                style={{ fontSize: 13, fontWeight: 500 }}
              />
            </XAxis>
            <YAxis
              dataKey="label"
              type="category"
              width={100}
              tick={{ fontSize: 12 }}
              tickLine={true}
              axisLine={true}
            />

            <Tooltip
              cursor={{ fill: "rgba(0,0,0,0.05)" }}
              content={({ payload }) => {
                if (payload && payload?.length) {
                  const item = payload[0]?.payload;
                  return (
                    <div className="bg-white border border-gray-200 rounded-md shadow-md p-2 text-xs">
                      <p className="font-semibold">{item?.label}</p>
                      <p>Calls: {item?.calls}</p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Bar dataKey="calls" barSize={16}>
              {records?.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default TermCodesChart;
