import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LabelList,
  Cell,
  Label,
} from "recharts";
import { useGetComplianceAndIssueQuery } from "../../services/compliance-and-issue-api";

interface ComplianceAndIssueBarChartProps {
  startDate: string;
  endDate: string;
}

const ComplianceAndIssueChart: React.FC<ComplianceAndIssueBarChartProps> = ({
  startDate,
  endDate,
}) => {
  const { data, isLoading, isError } = useGetComplianceAndIssueQuery({
    startDate: startDate,
    endDate: endDate,
  });

  const records = data?.data?.records || [];

  const colors = [
    "#F4C3BE",
    "#E9A9A2",
    "#DE8F86",
    "#D4756A",
    "#C26C63",
    "#A85956",
    "#8E4749",
    "#74353C",
    "#63100A",
  ];

  if (isLoading) return <div className="p-4">Loading...</div>;
  if (isError) return <div className="p-4 text-red-500">Failed to load data.</div>;
  if (!data || records?.length === 0) return <div className="p-4">No data available.</div>;

  return (
    <div className="border border-gray-300 shadow-md rounded-md p-4 bg-white">
      <h2 className="text-lg font-semibold mb-4">Compliance & Top Issues</h2>

      <div style={{ scrollbarWidth: "thin", scrollbarColor: "#C26C63 transparent" }} className="h-[290px] overflow-y-auto scrollbar-thin scrollbar-track-transparent pr-2">
        <ResponsiveContainer width="100%" height={records?.length * 32}>
          <BarChart
            layout="vertical"
            data={records}
            margin={{ top: 10, right: 30, left: 0, bottom: 10 }}
            barCategoryGap={6}
          >
            {/* <XAxis type="number" /> */}
            <XAxis type="number" tick={{ fontSize: 12 }}>
              <Label
                value="Issue Rate %"
                offset={-5}
                position="bottom"
                style={{ fontSize: 13, fontWeight: 500 }}
              />
            </XAxis>
            <YAxis
              dataKey="label"
              type="category"
              width={180}
              tick={{ fontSize: 12 }}
              tickLine={true}
              axisLine={true}
            />

            <Tooltip
              cursor={{ fill: "rgba(0,0,0,0.05)" }}
              content={({ payload }) => {
                if (payload && payload?.length) {
                  const item = payload[0]?.payload;
                  return (
                    <div className="bg-white border border-gray-200 rounded-md shadow-md p-2 text-xs">
                      <p className="font-semibold">{item?.label}</p>
                      <p>Calls: {item?.calls}</p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Bar dataKey="calls" barSize={14}>
              {records?.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
              ))}
              <LabelList
                dataKey="calls"
                position="right"
                fill="#333"
                fontSize={12}
                formatter={(value: any) =>
                  typeof value === "number" ? value?.toLocaleString() : value ?? ""
                }
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ComplianceAndIssueChart;
