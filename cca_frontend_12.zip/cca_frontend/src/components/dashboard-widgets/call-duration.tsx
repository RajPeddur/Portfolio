import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
  Label,
  Cell,
} from "recharts";
import { useGetCallDurationDataQuery } from "../../services/call-duration-api";

interface CallDurationBarChartProps {
    startDate: string;
    endDate: string;
}

const CallDurationChart: React.FC<CallDurationBarChartProps> = ({
    startDate,
    endDate,
}) => {
  const { data, isLoading, isError } = useGetCallDurationDataQuery({
    startDate: startDate,
    endDate: endDate,
  });

  if (isLoading) return <div className="text-gray-500 text-center py-6">Loading...</div>;
  if (isError) return <div className="text-red-500 text-center py-6">Error loading chart</div>;

  const records = data?.data?.records || [];

  // 🎨 Color palette for bars
  const colors = [
    "#A3CEF1",
    "#82B1D1",
    "#6A9FB5",
    "#4E89A9",
    "#367C99",
    "#2E6F91",
    "#1E5F82",
    "#0E4F72",
    "#003F63",
  ];

  // 🎯 Custom tooltip showing only hovered bar info
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload?.length) {
      const { label, calls, avgSeconds } = payload[0]?.payload;
      return (
        <div className="bg-white border border-gray-200 rounded-md shadow-md p-2 text-sm">
          <p className="font-semibold">{label}</p>
          <p>Calls: {calls.toLocaleString()}</p>
          <p>Avg Duration: {avgSeconds}s</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="border border-gray-300 shadow-md rounded-md p-4 bg-white">
      <h2 className="text-lg font-semibold mb-4">Calls Duration</h2>

      <ResponsiveContainer width="100%" height={250}>
        <BarChart data={records} margin={{ top: 0, right: 30, left: 30, bottom: 40 }}>
          {/* <CartesianGrid strokeDasharray="3 3" /> */}

          <XAxis dataKey="label" tick={{ fontSize: 12 }}>
            <Label
              value="Seconds"
              offset={20}
              position="bottom"
              style={{ fontSize: 13, fontWeight: 500 }}
            />
          </XAxis>

          <YAxis tickFormatter={(v) => (v >= 1000 ? `${v / 1000}K` : v)} tick={{ fontSize: 12 }}>
            <Label
              value="No. of calls"
              angle={-90}
              position="insideLeft"
              style={{ textAnchor: "middle", fontSize: 13, fontWeight: 500 }}
            />
          </YAxis>

          <Tooltip content={<CustomTooltip />} cursor={{ fill: "rgba(0,0,0,0.05)" }} />

          <Bar dataKey="calls">
            {records?.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default CallDurationChart;
