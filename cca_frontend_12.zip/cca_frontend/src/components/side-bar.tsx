import { ArrowLeftIcon } from "@heroicons/react/24/solid";
import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { ArrowRightIcon } from "@heroicons/react/24/outline";
import { useTheme } from "../context/theme-context";
import { menuData } from "../api/dummy-data/menuData";
import DynamicHeroIcon from "./common/dynamic-icon-solid";

const Sidebar = () => {
    const { theme } = useTheme();
    const [collapsed, setCollapsed] = useState(false);
    const location = useLocation();

    const toggleSidebar = () => setCollapsed(!collapsed);

    return (
        <div
            className={` bg-white h-screen border-r-2 border-gray-200 transition-all duration-300 flex flex-col ${collapsed ? "w-20" : "w-60"
                }`}
        >
            <div className="flex items-center justify-between py-1.5 px-3 bg-gray-200">
                <img
                    src={theme?.logoUrl}
                    alt="Logo"
                    className="h-12 object-contain"
                />
                {collapsed ?
                    <button className=" cursor-pointer bg-gray-800 border-2 border-gray-200 text-gray-200 rounded-md p-1 -mr-7 z-10" onClick={toggleSidebar}>
                        <ArrowRightIcon className=" w-5 h-5" />
                    </button> :
                    <button className=" cursor-pointer bg-gray-800 border-2 border-gray-200 text-gray-200 rounded-md p-1 -mr-7 z-10" onClick={toggleSidebar}>
                        <ArrowLeftIcon className=" w-5 h-5" />
                    </button>
                }
            </div>
            <div className=" border-b-3 border-(--primaryColor) flex justify-center p-2">
                <h1 className=" font-bold text-xl">VoisAI</h1>
            </div>
            <nav style={{ scrollbarWidth: "thin" }} className="flex-1 overflow-y-auto space-y-2">
                {menuData?.map((section: any) => (
                    <div key={section?.title}>
                        {!collapsed && (
                            <p className="text-(--textColor) font-bold uppercase mt-4 mb-2 px-2">
                                {section?.title}
                            </p>
                        )}
                        {section?.children?.map((item: any, index: any) => {
                            const active = location?.pathname === item?.path;
                            return (
                                <div key={index}>
                                    {collapsed ?
                                        <Link
                                            key={item?.title}
                                            to={item?.path}
                                            className={`flex items-center gap-3 justify-center px-3 py-2 hover:bg-indigo-100 hover:text-(--primaryColor) transition ${active ? "bg-indigo-100 text-(--primaryColor)" : "text-(--textColor)"
                                                }`}
                                        >
                                            <DynamicHeroIcon name={item?.icon} type="solid" className="w-5 h-5" />
                                        </Link>
                                        :
                                        <Link
                                            key={item?.title}
                                            to={item?.path}
                                            className={`flex items-center gap-3 px-3 py-2 hover:bg-indigo-100 hover:shadow-md hover:text-(--primaryColor) transition ${active ? "bg-indigo-100 text-(--primaryColor) shadow-md" : "text-(--textColor)"
                                                }`}
                                        >
                                            <DynamicHeroIcon name={item?.icon} type="solid" className="w-4 h-4" />
                                            <span className=" text-sm font-semibold">{item?.title}</span>
                                        </Link>
                                    }
                                </div>
                            );
                        })}
                    </div>
                ))}
            </nav>
        </div>
    );
};

export default Sidebar;

// import { ArrowLeftIcon } from "@heroicons/react/24/solid";
// import { ArrowRightIcon } from "@heroicons/react/24/outline";
// import { motion, AnimatePresence } from "framer-motion";
// import { useState } from "react";
// import { Link, useLocation } from "react-router-dom";
// import { useTheme } from "../context/theme-context";
// import { menuData } from "../api/dummy-data/menuData";
// import DynamicHeroIcon from "./common/dynamic-icon-solid";

// const Sidebar = () => {
//   const { theme } = useTheme();
//   const [collapsed, setCollapsed] = useState(false);
//   const location = useLocation();

//   const toggleSidebar = () => setCollapsed(!collapsed);

//   return (
//     <div className="relative h-screen">
//       {/* Motion sidebar */}
//       <motion.div
//         animate={{ width: collapsed ? 80 : 240 }}
//         transition={{ duration: 0.3, ease: "easeInOut" }}
//         className="bg-white h-full border-r-2 border-gray-200 flex flex-col shadow-sm"
//       >
//         {/* Header */}
//         <div className="flex items-center justify-center py-2 px-3 bg-gray-200 relative">
//           <img
//             src={theme?.logoUrl}
//             alt="Logo"
//             className="h-12 object-contain transition-all duration-300"
//           />
//         </div>

//         {/* Title */}
//         <div className="border-b border-gray-300 flex justify-center p-2">
//           <AnimatePresence>
//             {!collapsed && (
//               <motion.h1
//                 key="title"
//                 initial={{ opacity: 0, y: -10 }}
//                 animate={{ opacity: 1, y: 0 }}
//                 exit={{ opacity: 0, y: -10 }}
//                 transition={{ duration: 0.2 }}
//                 className="font-bold text-xl text-gray-800"
//               >
//                 VoisAI
//               </motion.h1>
//             )}
//           </AnimatePresence>
//         </div>

//         {/* Menu */}
//         <nav
//           style={{ scrollbarWidth: "thin" }}
//           className="flex-1 overflow-y-auto space-y-2 p-2"
//         >
//           {menuData?.map((section: any) => (
//             <div key={section?.title}>
//               <AnimatePresence>
//                 {!collapsed && (
//                   <motion.p
//                     key={section.title}
//                     initial={{ opacity: 0, y: -5 }}
//                     animate={{ opacity: 1, y: 0 }}
//                     exit={{ opacity: 0, y: -5 }}
//                     transition={{ duration: 0.2 }}
//                     className="text-gray-600 font-bold uppercase mt-4 mb-2 px-2"
//                   >
//                     {section?.title}
//                   </motion.p>
//                 )}
//               </AnimatePresence>

//               {section?.children?.map((item: any, index: any) => {
//                 const active = location?.pathname === item?.path;
//                 return (
//                   <Link
//                     key={index}
//                     to={item?.path}
//                     className={`flex items-center px-3 py-2 rounded-md transition-all duration-200 ${
//                       active
//                         ? "bg-indigo-100 text-(--primaryColor) shadow-md"
//                         : "text-gray-700 hover:bg-indigo-100 hover:shadow-md"
//                     }`}
//                   >
//                     <DynamicHeroIcon name={item?.icon} type="solid" className="w-5 h-5" />
//                     <AnimatePresence>
//                       {!collapsed && (
//                         <motion.span
//                           key="label"
//                           initial={{ opacity: 0, x: -10 }}
//                           animate={{ opacity: 1, x: 0 }}
//                           exit={{ opacity: 0, x: -10 }}
//                           transition={{ duration: 0.2 }}
//                           className="ml-3 text-sm font-semibold"
//                         >
//                           {item?.title}
//                         </motion.span>
//                       )}
//                     </AnimatePresence>
//                   </Link>
//                 );
//               })}
//             </div>
//           ))}
//         </nav>
//       </motion.div>

//       {/* Toggle Button (outside sidebar) */}
//       <button
//         onClick={toggleSidebar}
//         className="absolute top-3 -right-3.5 bg-gray-800 border-2 border-gray-200 text-gray-200 rounded-md p-1 z-50 hover:bg-gray-700 transition"
//       >
//         {collapsed ? (
//           <ArrowRightIcon className="w-5 h-5" />
//         ) : (
//           <ArrowLeftIcon className="w-5 h-5" />
//         )}
//       </button>
//     </div>
//   );
// };

// export default Sidebar;

