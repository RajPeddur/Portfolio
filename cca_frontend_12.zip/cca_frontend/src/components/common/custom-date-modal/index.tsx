import React, { useEffect, useRef, useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

export interface RangePayload {
  fromDate: Date;
  toDate: Date;
}

interface CustomDatePopoverProps {
  open: boolean;
  anchorRef: React.RefObject<HTMLElement | null>;
  onClose: () => void;
  onApply: (range: RangePayload) => void;
}

const CustomDatePopover: React.FC<CustomDatePopoverProps> = ({
  open,
  anchorRef,
  onClose,
  onApply,
}) => {
  const [fromDate, setFromDate] = useState<Date | null>(null);
  const [toDate, setToDate] = useState<Date | null>(null);
  const [maxToDate, setMaxToDate] = useState<Date | null>(null);
  const wrapperRef = useRef<HTMLDivElement | null>(null);
  const [style, setStyle] = useState<React.CSSProperties>();

  // Set 3-month limit (and disallow future)
  useEffect(() => {
    if (!fromDate) {
      setMaxToDate(null);
      setToDate(null);
      return;
    }
    const max = new Date(fromDate);
    max.setMonth(max.getMonth() + 3);
    const today = new Date();
    setMaxToDate(max > today ? today : max);
  }, [fromDate]);

  // Position popup under the anchor button
  useEffect(() => {
    if (!open) return;
    const anchor = anchorRef.current;
    if (!anchor) return;
    const rect = anchor.getBoundingClientRect();
    const scrollY = window.scrollY;
    const scrollX = window.scrollX;
    const margin = 0;

    let left = rect.left + scrollX;
    let top = rect.bottom + margin + scrollY;

    setStyle({
      position: "absolute",
      left,
      top,
      width: 300,
      zIndex: 9999,
    });
  }, [open, anchorRef]);

  // Close when clicking outside
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const t = e.target as Node;
      if (
        wrapperRef.current?.contains(t) ||
        anchorRef.current?.contains(t)
      )
        return;
      onClose();
    };
    if (open) document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open, onClose, anchorRef]);

  if (!open) return null;

  return (
    <div
      ref={wrapperRef}
      // style={style}
      className="bg-white border border-gray-200 rounded-lg shadow-xl p-4 absolute top-6.5 right-0"
    >
      <h4 className="text-sm font-semibold mb-3">Select Custom Range</h4>

      <div className="space-y-3">
        <div>
          <label className="block text-xs text-gray-600 mb-1">From</label>
          <DatePicker
            selected={fromDate ?? undefined}
            onChange={(d: Date | null) => setFromDate(d)}
            maxDate={new Date()}
            placeholderText="Select from date"
            className="w-full border rounded-md px-3 py-2 text-sm"
            dateFormat="dd/MM/yyyy"
          />
        </div>

        <div>
          <label className="block text-xs text-gray-600 mb-1">To</label>
          <DatePicker
            selected={toDate ?? undefined}
            onChange={(d: Date | null) => setToDate(d)}
            minDate={fromDate ?? undefined}
            maxDate={maxToDate ?? new Date()}
            disabled={!fromDate}
            placeholderText="Select to date"
            className="w-full border rounded-md px-3 py-2 text-sm disabled:bg-gray-100 disabled:cursor-not-allowed"
            dateFormat="dd/MM/yyyy"
          />
        </div>
      </div>

      <div className="flex justify-end gap-2 mt-4">
        <button
          type="button"
          onClick={() => {
            setFromDate(null);
            setToDate(null);
          }}
          className="px-3 py-1 rounded-md text-xs border text-gray-600 hover:bg-gray-50 cursor-pointer"
        >
          Clear
        </button>
        <button
          type="button"
          onClick={(e) => {
            e.preventDefault();
            if (!fromDate || !toDate) {
              alert("Please select both From and To dates.");
              return;
            }
            onApply({ fromDate, toDate });
            onClose();
          }}
          className="px-3 py-1 rounded-md text-xs bg-blue-600 text-white hover:bg-blue-700 cursor-pointer"
        >
          Apply
        </button>
      </div>
    </div>
  );
};

export default CustomDatePopover;
