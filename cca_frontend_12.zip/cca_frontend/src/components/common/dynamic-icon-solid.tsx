import * as SolidIcons from "@heroicons/react/24/solid";
import * as OutlineIcons from "@heroicons/react/24/outline";
import React from "react";

type HeroIconName = keyof typeof SolidIcons | keyof typeof OutlineIcons;

interface DynamicHeroIconProps {
  name: HeroIconName;
  type?: "solid" | "outline";
  className?: string;
}

const DynamicHeroIcon: React.FC<DynamicHeroIconProps> = ({
  name,
  type = "outline",
  className = "w-6 h-6",
}) => {
  const IconSet = type === "solid" ? SolidIcons : OutlineIcons;
  const IconComponent = IconSet[name as keyof typeof IconSet];

  if (!IconComponent) {
    console.warn(`⚠️ HeroIcon "${name}" not found in ${type} set.`);
    return null;
  }

  return <IconComponent className={className} />;
};

export default DynamicHeroIcon;
