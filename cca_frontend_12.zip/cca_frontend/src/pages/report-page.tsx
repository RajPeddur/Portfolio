import { useState, useEffect, useMemo } from "react";
import {
  XMarkIcon,
  FunnelIcon,
  CalendarIcon,
  MagnifyingGlassIcon,
} from "@heroicons/react/24/outline";
import { motion, AnimatePresence } from "framer-motion";
import { useGetTermCodesQuery } from "../services/term-codes-api";

const ReportsTable = () => {
  // 🔹 Local UI States
  const [search, setSearch] = useState("");
  const [createdBy, setCreatedBy] = useState("");
  const [isScheduled, setIsScheduled] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [showOverlay, setShowOverlay] = useState(false);
  const [extraFilters, setExtraFilters] = useState({ tag: "", category: "" });
  const [filterCount, setFilterCount] = useState(0);

  // 🔹 Build payload dynamically based on filters
  const queryPayload = useMemo(() => {
    return {
      startDate: selectedDate || "2025-11-01",
      endDate: "2025-11-06",
      search,
      createdBy,
      isScheduled,
      ...extraFilters,
    };
  }, [search, createdBy, isScheduled, selectedDate, extraFilters]);

  // 🔹 Fetch data from API
  const { data, isLoading, refetch } = useGetTermCodesQuery(
    { startDate: queryPayload.startDate, endDate: queryPayload.endDate },
    { skip: false }
  );

  // 🔹 Trigger refetch on filter changes
  useEffect(() => {
    refetch();
  }, [queryPayload, refetch]);

  // 🔹 Example: convert API response into report list
  const reports = useMemo(() => {
    // you can replace this mapping when your backend sends actual report data
    if (!data?.data?.records) return [];
    return data.data.records.map((r, i) => ({
      id: i + 1,
      name: `${r.label} Report`,
      description: `${r.label} summary based on ${data.data.timeRange}`,
      createdBy: createdBy || "admin@company.com",
      schedule: selectedDate ? `Scheduled on ${selectedDate}` : "",
      scheduled: Boolean(selectedDate),
    }));
  }, [data, createdBy, selectedDate]);

  // 🔹 Filter Count Badge
  useEffect(() => {
    const count = [
      search,
      createdBy,
      isScheduled,
      selectedDate,
      extraFilters.tag,
      extraFilters.category,
    ].filter(Boolean).length;
    setFilterCount(count);
  }, [search, createdBy, isScheduled, selectedDate, extraFilters]);

  const clearFilters = () => {
    setSearch("");
    setCreatedBy("");
    setIsScheduled("");
    setSelectedDate("");
    setExtraFilters({ tag: "", category: "" });
  };

  const handleDownload = (type:any, name:any) => {
    console.log(`${type} download for ${name}`);
  };

  return (
    <div className="p-4 bg-gray-50 min-h-screen">
      {/* 🔹 Top Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        {/* Search Input */}
        <div className="relative bg-white">
          <MagnifyingGlassIcon className="absolute left-2.5 top-1.5 h-4 w-4 text-gray-500" />
          <input
            type="text"
            placeholder="Search Report Name"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 pr-8 py-1 border border-gray-300 rounded-md w-64 text-sm"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-2 top-2.5 text-gray-400 hover:text-gray-600"
            >
              <XMarkIcon className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* Created By */}
        <select
          value={createdBy}
          onChange={(e) => setCreatedBy(e.target.value)}
          className="border px-3 py-1 rounded-md text-sm bg-white border-gray-300"
        >
          <option value="">Created By</option>
          <option value="admin@company.com">admin@company.com</option>
          <option value="qa.lead@company.com">qa.lead@company.com</option>
          <option value="supervisor@company.com">supervisor@company.com</option>
        </select>

        {/* Is Scheduled */}
        <select
          value={isScheduled}
          onChange={(e) => setIsScheduled(e.target.value)}
          className="border px-3 py-1 rounded-md text-sm bg-white border-gray-300"
        >
          <option value="">Is Scheduled</option>
          <option value="true">Scheduled</option>
          <option value="false">Unscheduled</option>
        </select>

        {/* Date Selector */}
        <button
          onClick={() => {
            const newDate = prompt("Enter date & time (YYYY-MM-DD HH:mm)");
            if (newDate) setSelectedDate(newDate);
          }}
          className="flex items-center gap-2 border px-3 py-1 rounded-md border-gray-300 hover:bg-gray-100 text-sm bg-white"
        >
          <CalendarIcon className="h-5 w-5 text-gray-600" />
          {selectedDate || "Select Date & Time"}
        </button>

        {/* Filter Button */}
        <div className="flex items-center gap-2 ml-auto">
          <button
            onClick={() => setShowOverlay(true)}
            className="relative flex items-center gap-2 border px-3 py-1 border-gray-300 rounded-md hover:bg-gray-100 text-sm bg-white"
          >
            <FunnelIcon className="h-4 w-4 text-gray-600" />
            Filter
            {filterCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-blue-500 text-white text-xs px-1 rounded-full">
                {filterCount}
              </span>
            )}
          </button>
          {filterCount > 0 && (
            <button
              onClick={clearFilters}
              className="text-gray-500 hover:text-gray-700"
              title="Clear filters"
            >
              <XMarkIcon className="h-5 w-5" />
            </button>
          )}
        </div>
      </div>

      {/* 🔹 Table */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        {isLoading ? (
          <div className="text-center py-10 text-gray-500">Loading reports...</div>
        ) : reports?.length === 0 ? (
          <div className="text-center py-10 text-gray-500">No reports found.</div>
        ) : (
          <table className="min-w-full border-2 border-indigo-100 text-sm">
            <thead className="bg-indigo-100 text-left text-gray-700">
              <tr>
                <th className="px-4 py-2">Report Name</th>
                <th className="px-4 py-2">Description</th>
                <th className="px-4 py-2">Created By</th>
                <th className="px-4 py-2">Schedule</th>
                <th className="px-4 py-2">Download</th>
              </tr>
            </thead>
            <tbody>
              {reports?.map((r) => (
                <tr key={r.id} className="border-t border-indigo-100 hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium">{r.name}</td>
                  <td className="px-4 py-3 text-gray-600">
                    {r.description}
                    {r.scheduled && (
                      <span className="ml-2 bg-yellow-200 text-yellow-800 text-xs px-2 py-1 rounded-md">
                        Scheduled
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3">{r.createdBy}</td>
                  <td className="px-4 py-3">{r.schedule || "—"}</td>
                  <td className="px-4 py-3 flex gap-2">
                    <button
                      onClick={() => handleDownload("PDF", r.name)}
                      className="text-red-500 border border-red-400 px-3 py-1 rounded-md text-xs"
                    >
                      PDF
                    </button>
                    <button
                      onClick={() => handleDownload("Excel", r.name)}
                      className="text-yellow-600 border border-yellow-400 px-3 py-1 rounded-md text-xs"
                    >
                      Excel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* 🔹 Pagination */}
      <div className="flex justify-between items-center mt-4">
        <div className="flex gap-2">
          {[20, 100, 500, 2500].map((n) => (
            <button
              key={n}
              className="border px-3 py-1 rounded bg-white hover:bg-gray-100 text-sm border-gray-300"
            >
              {n}
            </button>
          ))}
        </div>
        <button className="border px-4 py-1 rounded bg-white border-gray-300 hover:bg-gray-100 text-sm">
          Load More
        </button>
      </div>

      {/* 🔹 Filter Overlay */}
      <AnimatePresence>
        {showOverlay && (
          <motion.div
            className="fixed inset-0 bg-black/30 flex justify-end z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              initial={{ x: 300 }}
              animate={{ x: 0 }}
              exit={{ x: 300 }}
              className="bg-white w-80 h-full shadow-lg p-5"
            >
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">More Filters</h2>
                <button
                  onClick={() => setShowOverlay(false)}
                  className="text-gray-600 hover:text-gray-800"
                >
                  <XMarkIcon className="h-5 w-5" />
                </button>
              </div>

              {/* Extra Filter Fields */}
              <div className="space-y-3">
                <input
                  placeholder="Filter by tag"
                  value={extraFilters.tag}
                  onChange={(e) =>
                    setExtraFilters((prev) => ({
                      ...prev,
                      tag: e.target.value,
                    }))
                  }
                  className="w-full border px-3 py-2 rounded text-sm"
                />
                <input
                  placeholder="Filter by category"
                  value={extraFilters.category}
                  onChange={(e) =>
                    setExtraFilters((prev) => ({
                      ...prev,
                      category: e.target.value,
                    }))
                  }
                  className="w-full border px-3 py-2 rounded text-sm"
                />
              </div>

              <button
                onClick={() => setShowOverlay(false)}
                className="mt-5 w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 text-sm"
              >
                Submit
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ReportsTable;
