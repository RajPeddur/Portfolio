import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { EnvelopeIcon, ExclamationCircleIcon, EyeIcon, EyeSlashIcon, LockClosedIcon } from "@heroicons/react/24/outline";
import { loginAPI } from "../api/auth";
import { localData } from "../api/utils";
import { useTheme } from "../context/theme-context";
import Loader from "../components/common/loader";

const Login = () => {
  const navigate = useNavigate();
  const { theme } = useTheme();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [client, setClient] = useState("");
  const [loginError, setLoginError] = useState("");
  const [remember, setRemember] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await loginAPI({ email, password });
      localData.add("token", response.token);
      toast.success("Welcome back!");
      navigate("/dashboard");
    } catch (err: any) {
      setLoginError(err?.message)
      toast.error(err?.message || "Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      {loading && <Loader />}
      <div className=" grid grid-cols-2">
        <div className=" bg-white flex items-center justify-center overflow-hidden px-4">
          <div className="w-full max-w-md">
            <div className="flex justify-center items-center gap-2 mb-6">
              <img
                src={theme?.logoUrl}
                alt="Logo"
                className="h-12 object-contain"
              />
            </div>
            <div className="relative z-10 bg-white rounded-2xl border-2 border-gray-200 p-5">
              <h2 className="text-center text-2xl font-bold text-(--textColor)">
                Log In
              </h2>
              <p className="text-center text-gray-500 mt-2">
                Welcome! Please enter your details
              </p>
              {loginError ?
                <div className=" h-7">
                  <p className=" flex gap-1 items-center text-red-600 font-semibold text-sm justify-center mt-1">
                    <ExclamationCircleIcon className=" w-5 h-5" />
                    {loginError}
                  </p>
                </div>
                :
                <div className=" h-8"></div>
              }
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-(--textColor) mb-2">
                    Email
                  </label>
                  <div className="relative">
                    <EnvelopeIcon className="w-5 h-5 absolute left-3 top-2.5 text-gray-400" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      placeholder="Enter your email"
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-(--primaryColor) focus:border-(--primaryColor) outline-none text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-(--textColor) mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <LockClosedIcon className="w-5 h-5 absolute left-3 top-2.5 text-gray-400" />
                    <input
                      type={showPass ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      placeholder="Enter your password"
                      className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-(--primaryColor) focus:border-(--primaryColor) outline-none text-sm"
                    />
                    <div onClick={() => showPass ? setShowPass(false) : setShowPass(true)} className=' absolute top-2 right-3 text-gray-400 cursor-pointer'>
                      {showPass ?
                        <EyeIcon className=' h-6 w-6'></EyeIcon>
                        :
                        <EyeSlashIcon className=' h-6 w-6'></EyeSlashIcon>
                      }
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-(--textColor) mb-2">
                    Choose a Client
                  </label>
                  <select
                    value={client}
                    onChange={(e) => setClient(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 text-gray-500 rounded-md focus:ring-2 focus:ring-(--primaryColor) focus:border-(--primaryColor) outline-none text-sm"
                  >
                    <option value="">Select</option>
                    <option value="tenant-A">Tenant A</option>
                    <option value="tenant-B">Tenant B</option>
                  </select>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-600">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={remember}
                      onChange={() => setRemember(!remember)}
                      className="w-4 h-4 accent-(--primaryColor)"
                    />
                    Keep me logged in
                  </label>
                  <button
                    type="button"
                    className="text-[#4a6fb0] hover:underline font-semibold"
                  >
                    Forgot Password
                  </button>
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-1 rounded-md text-white font-semibold bg-[#4a6fb0] cursor-pointer hover:opacity-90 transition disabled:opacity-50 flex justify-center items-center gap-2"
                >
                  {loading ? "Logging in..." : "Log In"}
                </button>
              </form>
            </div>
          </div>
        </div>
        <div className=" flex items-center justify-center min-h-screen bg-[#eaeaea] overflow-hidden px-4">
          <img src="imges/login.png" className=" h-9/12" />
        </div>
      </div>
    </div>
  );
};

export default Login;
