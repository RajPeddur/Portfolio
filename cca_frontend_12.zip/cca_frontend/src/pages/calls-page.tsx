// src/components/CallsPage.tsx
import { useEffect, useMemo, useState, type JSX } from "react";
import type { CallRecord } from "../api/dummy-data/calls-listing-data";
import mockDataGenerator, { TAG_POOL } from "../api/dummy-data/calls-listing-data";
import FilterHeader from "../components/calls-listing/calls-filter-header";
import AdvanceSearchDropdown from "../components/calls-listing/advance-search";
import CallsTable from "../components/calls-listing/listing-table";
import SideFilterPanel from "../components/calls-listing/filter-modal";
import { motion, AnimatePresence } from "framer-motion";
import { XMarkIcon } from "@heroicons/react/24/outline";

export interface Filters {
    agent: string;
    assignTo: string;
    dateFrom: string | null; // yyyy-mm-dd
    dateTo: string | null;
    duration: string; // e.g. "00:10"
    tags: string[];
    flagged: "" | "true" | "false";
}

const INITIAL_LIMIT = 20;

export default function CallsPage(): JSX.Element {
    const [pool] = useState<CallRecord[]>(() => mockDataGenerator(500));
    const [limit, setLimit] = useState<number>(INITIAL_LIMIT);
    const [visible, setVisible] = useState<CallRecord[]>(() => pool.slice(0, INITIAL_LIMIT));
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [showSideFilter, setShowSideFilter] = useState(false);
    const [showAdvance, setShowAdvance] = useState(false);
    const [sortAsc, setSortAsc] = useState<boolean>(false);

    const [selectedCall, setSelectedCall] = useState<CallRecord | null>(null);
    const [panelWidth, setPanelWidth] = useState<number>(400);
    const [isDragging, setIsDragging] = useState<boolean>(false);

    // --- Dragging behavior ---
    const handleMouseDown = () => setIsDragging(true);

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (!isDragging) return;

            const newWidth = window.innerWidth - e.clientX;
            // restrict size between 300px and 70% of screen width
            if (newWidth > 300 && newWidth < window.innerWidth * 0.7) {
                setPanelWidth(newWidth);
            }
        };

        const handleMouseUp = () => setIsDragging(false);

        if (isDragging) {
            window.addEventListener("mousemove", handleMouseMove);
            window.addEventListener("mouseup", handleMouseUp);
        }

        return () => {
            window.removeEventListener("mousemove", handleMouseMove);
            window.removeEventListener("mouseup", handleMouseUp);
        };
    }, [isDragging]);


    const [filters, setFilters] = useState<Filters>({
        agent: "",
        assignTo: "",
        dateFrom: null,
        dateTo: null,
        duration: "",
        tags: [],
        flagged: "",
    });

    const filtered = useMemo(() => {
        const arr = visible.filter((r) => {
            if (filters.agent && !r.agent.toLowerCase().includes(filters.agent.toLowerCase())) return false;
            if (filters.assignTo && r.assignTo !== filters.assignTo) return false;
            if (filters.flagged === "true" && !r.flagged) return false;
            if (filters.flagged === "false" && r.flagged) return false;
            if (filters.dateFrom && new Date(r.timestamp) < new Date(filters.dateFrom)) return false;
            if (filters.dateTo && new Date(r.timestamp) > new Date(filters.dateTo)) return false;
            if (filters.duration) {
                const parts = filters.duration.split(":").map((p) => Number(p));
                const seconds = parts.length === 2 ? parts[0] * 60 + parts[1] : Number(filters.duration);
                if (!Number.isNaN(seconds) && r.durationSeconds > seconds) return false;
            }
            if (filters.tags.length > 0) {
                for (const t of filters.tags) if (!r.tags.includes(t)) return false;
            }
            return true;
        });
        arr.sort((a, b) =>
            (new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()) * (sortAsc ? 1 : -1)
        );
        return arr;
    }, [visible, filters, sortAsc]);

    function loadMore() {
        const next = Math.min(pool.length, limit + INITIAL_LIMIT);
        setLimit(next);
        setVisible(pool.slice(0, next));
    }

    function toggleSelect(id: string, checked: boolean) {
        setSelectedIds((s) => {
            const clone = new Set(s);
            if (checked) clone.add(id);
            else clone.delete(id);
            return clone;
        });
    }

    function selectAll(checked: boolean) {
        if (checked) setSelectedIds(new Set(filtered.map((r) => r.id)));
        else setSelectedIds(new Set());
    }

    function clearFilters() {
        setFilters({
            agent: "",
            assignTo: "",
            dateFrom: null,
            dateTo: null,
            duration: "",
            tags: [],
            flagged: "",
        });
    }

    return (
        <>
            <div className="flex w-full bg-gray-50">
                <div className={` relative transition-all duration-300 p-5 ${selectedCall ? "border-r border-gray-200" : ""
                    }`}
                    style={{
                        width: selectedCall ? `calc(100% - ${panelWidth}px)` : "100%",
                    }}>
                    <div className="flex items-center gap-3">
                        <FilterHeader
                            selectedIds={selectedIds}
                            filters={filters}
                            onChange={setFilters}
                            onClear={clearFilters}
                            onOpenSideFilter={() => setShowSideFilter((s) => !s)}
                            onToggleAdvance={() => setShowAdvance((s) => !s)}
                            tagOptions={TAG_POOL}
                        />
                    </div>

                    {/* Advance search - anchored dropdown / bottom sheet handled inside */}
                    {showAdvance && (
                        <AdvanceSearchDropdown
                            onClose={() => setShowAdvance(false)}
                            onApply={(vals) => {
                                setFilters((f) => ({ ...f, ...vals }));
                                setShowAdvance(false);
                            }}
                        />
                    )}

                    {showSideFilter && (
                        <SideFilterPanel
                            initial={filters}
                            // Below Committed code will be use when get filter from header input.
                            // initial={{
                            //     combinator: "and",
                            //     rules: [
                            //         { field: "collectorName", operator: "contains", value: "John" },
                            //         { field: "", operator: "", value: "" },
                            //     ],
                            // }}
                            onClose={() => setShowSideFilter(false)}
                            onApply={(vals) => {
                                console.log("Applied advanced filter JSON:", vals);
                                setFilters((f) => ({ ...f, ...vals }));
                                setShowSideFilter(false);
                            }} open={false} />
                    )}
                    <div className="text-sm text-gray-500 text-right">{filtered?.length} of {pool?.length}</div>

                    <CallsTable
                        selectedCall={selectedCall}
                        setSelectedCall={setSelectedCall}
                        rows={filtered}
                        selectedIds={selectedIds}
                        onSelect={toggleSelect}
                        onSelectAll={selectAll}
                        onToggleSort={() => setSortAsc((s) => !s)}
                        sortAsc={sortAsc}
                    />

                    <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-2">
                            <label className="text-sm">Show</label>
                            <select
                                value={limit}
                                onChange={(e) => {
                                    const v = Number(e.target.value);
                                    setLimit(v);
                                    setVisible(pool.slice(0, v));
                                }}
                                className="border rounded px-2 py-1 text-sm"
                            >
                                <option value={20}>20</option>
                                <option value={100}>100</option>
                                <option value={500}>500</option>
                                <option value={2500}>2500</option>
                            </select>
                        </div>

                        <div className="flex items-center gap-3">
                            <div className="text-sm text-gray-500">Showing {filtered.length} / {pool.length}</div>
                            <button onClick={loadMore} className="px-3 py-1 border rounded text-sm">Load More</button>
                        </div>
                    </div>
                </div>
                {selectedCall && (
                    <div
                        className={`w-1 cursor-col-resize ${isDragging
                            ? "bg-blue-400 shadow-[0_0_5px_#60a5fa]"
                            : "bg-gray-300 hover:bg-gray-400"
                            } transition-all duration-150`}
                        onMouseDown={handleMouseDown}
                    />
                )}
                {/* Right Section: Animated Details Panel */}
                <AnimatePresence>
                    {selectedCall && (
                        <motion.div
                            key="details-panel"
                            initial={{ x: panelWidth, opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            exit={{ x: panelWidth, opacity: 0 }}
                            transition={{ type: "tween", duration: 0.3 }}
                            className="bg-white shadow-xl border-l border-gray-200 overflow-y-auto relative"
                            style={{
                                width: `${panelWidth}px`,
                                transition: isDragging ? "none" : "width 0.2s ease",
                            }}
                        >
                            {/* Header */}
                            <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 bg-gray-100 sticky top-0 z-10">
                                <h2 className="text-lg font-semibold text-gray-700">
                                    Call Details
                                </h2>
                                <button
                                    onClick={() => setSelectedCall(null)}
                                    className="p-1 rounded hover:bg-gray-200"
                                >
                                    <XMarkIcon className="h-5 w-5 text-gray-600" />
                                </button>
                            </div>

                            {/* Details Content */}
                            <div className="p-4 space-y-3">
                                <div>
                                    <p className="text-sm text-gray-500">Agent</p>
                                    <p className="font-medium text-gray-800">{selectedCall.agent}</p>
                                </div>
                                <div>
                                    <p className="text-sm text-gray-500">Timestamp</p>
                                    <p className="font-medium text-gray-800">
                                        {selectedCall.timestamp}
                                    </p>
                                </div>
                                <div>
                                    <p className="text-sm text-gray-500">Duration</p>
                                    <p className="font-medium text-gray-800">
                                        {selectedCall.duration}
                                    </p>
                                </div>
                                <div>
                                    <p className="text-sm text-gray-500">Notes</p>
                                    {/* <p className="text-gray-700">{selectedCall.notes}</p> */}
                                </div>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </>
    );
}
