// // src/pages/Dashboard.tsx
// import toast from "react-hot-toast";
// import { useNavigate } from "react-router-dom";

// const Dashboard = () => {
//   const navigate = useNavigate();

//   const handleLogout = () => {
//     localStorage.removeItem("token");
//     navigate("/");
//     toast.success("Logout.")
//   };

//   return (
//     <div className="flex flex-col items-center justify-center h-screen bg-gray-50">
//       <h1 className="text-3xl font-bold mb-4">Welcome to Dashboard 🎉</h1>
//       <p className="text-gray-600 mb-6">You are logged in successfully.</p>

//       <button
//         onClick={handleLogout}
//         className="bg-red-500 cursor-pointer text-white px-4 py-2 rounded-md hover:bg-red-600 transition-colors"
//       >
//         Logout
//       </button>
//     </div>
//   );
// };

// export default Dashboard;

import { Outlet } from "react-router-dom";
import Sidebar from "../components/side-bar";
import Header from "../components/header";

const Dashboard = () => {
  return (
    <div className="flex h-screen dark:bg-gray-900">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <Header />
        <main className=" overflow-y-auto">
          <Outlet />
        </main>
        <footer className="text-center py-1 text-gray-500 text-sm border-t border-gray-200">
          © 2025 First Credit Services Inc. All rights reserved
        </footer>
      </div>
    </div>
  );
};

export default Dashboard;

