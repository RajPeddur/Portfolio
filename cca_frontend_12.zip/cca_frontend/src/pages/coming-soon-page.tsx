import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";

export default function ComingSoonPage() {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem("token");
        navigate("/");
        toast.success("Logout.")
    };

    return (
        <>
            <div className=' container mx-auto'>
                <div className=' p-10 flex flex-col lg:flex-row justify-between items-center gap-5'>
                    <img className=' lg:hidden w-5/6 h-5/6' src='/imges/underCondruction.jpg' />
                    <div className=' flex flex-col gap-5'>
                        <h1 className=' text-8xl font-bold'>Oops !</h1>
                        <p className=' text-4xl font-bold'>Under Construction</p>
                        <p className=' text-xl -mb-3 font-semibold'>A little patience...</p>
                        <p className=' text-lg'>For now, this website is under construction. We are doing our best to present the new website version very soon.</p>
                        <button
                            onClick={handleLogout}
                            className="bg-(--primaryColor) w-40 cursor-pointer text-white px-4 py-2 rounded-md transition-colors"
                        >
                            Logout
                        </button>
                    </div>
                    <img className=' hidden lg:block w-5/6 h-5/6' src='/imges/underCondruction.jpg' />
                </div>
            </div>
        </>
    )
}
