import { ArrowDownIcon, ArrowPathIcon, ArrowRightIcon, ArrowUpIcon } from "@heroicons/react/24/outline";
import { useEffect, useRef, useState } from "react";
import DynamicHeroIcon from "../components/common/dynamic-icon-solid";
import SentimentTimeline from "../components/dashboard-widgets/sentiment-timeline";
import CallInsightsChart from "../components/dashboard-widgets/callInsights-chart";
import CustomDatePopover, { type RangePayload } from "../components/common/custom-date-modal";
import { formatLocalISODate } from "../api/utils";
import Loader from "../components/common/loader";
import { dashboardStatDataGetAPI } from "../api/dashboard-api-services";
import CallDurationChart from "../components/dashboard-widgets/call-duration";
import ComplianceAndIssueChart from "../components/dashboard-widgets/compliance-and-issue";
import TermCodesChart from "../components/dashboard-widgets/term-codes";
import ServiceChart from "../components/dashboard-widgets/service";
import AgentLeaderBoardTable from "../components/dashboard-widgets/agent-leaderboard";

const DashHomePage = () => {

  const [statData, setStatData] = useState([])

  const filter = [
    {
      key: "Yesterday",
      value: 1
    },
    {
      key: "Last 7 Days",
      value: 7
    },
    {
      key: "Last 30 Days",
      value: 30
    },
    {
      key: "Custom",
      value: 0
    },
  ]

  const [loading, setLoading] = useState(false);
  const [windowHeight, setWindowHeight] = useState(0);
  const [selectedFilter, setSelectedFilter] = useState<number>(7);
  const [customOpen, setCustomOpen] = useState(false);
  const [showingRange, setShowingRange] = useState<{
    from: Date;
    to: Date;
  }>({
    from: new Date(new Date().setDate(new Date().getDate() - selectedFilter)),
    to: new Date(),
  });

  useEffect(() => {

    // This code will run only in the browser
    const updateWindowHeight = () => {
      setWindowHeight(window?.innerHeight - 155)
    }

    // Set the initial window width
    updateWindowHeight()

    // Add event listener to track window resize
    window?.addEventListener('resize', updateWindowHeight)

    // Clean up the event listener when the component unmounts
    return () => {
      window?.removeEventListener('resize', updateWindowHeight)
    }
  }, [])

  const customBtnRef = useRef<HTMLButtonElement>(null);

  const today = new Date();
  const presetStart = new Date();
  presetStart.setDate(today.getDate() - selectedFilter);

  // const handleApply = (range: RangePayload) => {
  //   setShowingRange({ from: range.fromDate, to: range.toDate });
  //   setCustomOpen(false);
  // };

  const handleApply = (range: RangePayload) => {
    // When user applies a range, set filter=0 and update showingRange
    setSelectedFilter(0);
    setShowingRange({ from: range.fromDate, to: range.toDate });
    setCustomOpen(false);
    setLoading(true);
    setTimeout(() => setLoading(false), 1000);
  };

  const handlePresetClick = (value: number) => {
    setSelectedFilter(value);
    setCustomOpen(false);
    setLoading(true);
    setTimeout(() => setLoading(false), 1000);
  };

  // useEffect(() => {
  //   const from = new Date();
  //   from.setDate(today.getDate() - selectedFilter);
  //   setShowingRange({ from, to: today });
  // }, [selectedFilter])

  useEffect(() => {
    if (selectedFilter === 0) return; // skip when custom selected
    const from = new Date();
    from.setDate(today.getDate() - selectedFilter);
    setShowingRange({ from, to: today });
  }, [selectedFilter]);

  const handleLoad = () => {
    setLoading(true);
    setSelectedFilter(7)
    setTimeout(() => setLoading(false), 1000);
  };

  useEffect(() => {
    setLoading(true)
    dashboardStatDataGetAPI().then((res: any) => {
      setStatData(res);
      setLoading(false)
    }).catch((err) => { console.log(err), setLoading(false) });
  }, [])

  return (
    <>
      {loading && <Loader />}
      <div className=" container mx-auto">
        <div className=" flex items-center flex-wrap gap-3 sticky top-0 bg-gray-50 z-10 py-3 px-5">
          <div className="relative flex">
            {filter?.map((item) =>
              item?.value === 0 ? (
                <button
                  key={item?.key}
                  ref={customBtnRef}
                  onClick={() => {
                    setCustomOpen((p) => !p);
                  }}
                  className={`cursor-pointer px-3 py-1 border border-gray-400 rounded-sm font-semibold text-xs ${selectedFilter === 0 || customOpen
                    ? " bg-amber-50 text-(--accentColor)"
                    : "bg-white hover:bg-gray-50"
                    }`}
                >
                  {item?.key}
                </button>
              ) : (
                <button
                  key={item?.key}
                  onClick={() => handlePresetClick(item?.value)}
                  className={`cursor-pointer px-3 py-1 border border-gray-400 rounded-sm font-semibold text-xs ${selectedFilter === item?.value
                    ? " bg-amber-50 text-(--accentColor)"
                    : "bg-white hover:bg-gray-50"
                    }`}
                >
                  {item?.key}
                </button>
              )
            )}
            <CustomDatePopover
              open={customOpen}
              anchorRef={customBtnRef}
              onClose={() => setCustomOpen(false)}
              onApply={handleApply}
            />
          </div>
          <div className="text-xs font-medium flex items-center gap-2">
            <span className="ml-2 font-semibold ">
              Showing: {formatLocalISODate(showingRange?.from)}
            </span>
            <ArrowRightIcon className="w-3 h-3 " />
            <span className="font-semibold ">
              {formatLocalISODate(showingRange?.to)}
            </span>
          </div>
          <ArrowPathIcon onClick={handleLoad} className="w-4 h-4 text-(--accentColor) cursor-pointer" />
        </div>
        {/* <div style={{ scrollbarWidth: "thin", height: windowHeight }} className=" overflow-auto scrollbar-thin scrollbar-thumb-gray-900 scrollbar-track-gray-100 -mr-6 pr-6"> */}
        <div className=" grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5 px-5">
          {statData?.map((item: any, index: any) => (
            <div style={{color: '#2B426B'}} key={index} className=" border border-gray-300 shadow-md rounded-md p-4 bg-white space-y-2">
              <div className=" flex items-center justify-between">
                <h1 className=" font-semibold">{item?.title}</h1>
                <span style={{backgroundColor: '#2B426B'}} className=" rounded-full p-1.5">
                  <DynamicHeroIcon name={item?.icon} type="solid" className="w-3.5 h-3.5 text-white" />
                </span>
              </div>
              <h1 className=" text-3xl font-bold">{item?.count}</h1>
              {item?.growth ?
                <span style={{color: '#388B3C'}} className=" text-xs font-semibold flex items-center gap-1">
                  <ArrowUpIcon className=" w-3 h-3" /> + {item?.percent}% from last batch
                </span>
                :
                <span style={{color: '#FF3604'}} className=" text-xs font-semibold flex items-center gap-1">
                  <ArrowDownIcon className=" w-3 h-3" /> - {item?.percent}% from last batch
                </span>
              }
            </div>
          ))}
        </div>
        <div className=" mt-3 grid grid-cols-1 lg:grid-cols-7 gap-3 px-5 mb-2">
          <div className=" lg:col-span-4">
            <div>
              <SentimentTimeline startDate={formatLocalISODate(showingRange?.from)} endDate={formatLocalISODate(showingRange?.to)} />
            </div>
            <div className=" mt-2">
              <CallDurationChart startDate={formatLocalISODate(showingRange?.from)} endDate={formatLocalISODate(showingRange?.to)} />
            </div>
            <div className=" mt-2">
              <ComplianceAndIssueChart startDate={formatLocalISODate(showingRange?.from)} endDate={formatLocalISODate(showingRange?.to)} />
            </div>
          </div>
          <div className=" lg:col-span-3">
            <div>
              <CallInsightsChart startDate={formatLocalISODate(showingRange?.from)} endDate={formatLocalISODate(showingRange?.to)} />
            </div>
            <div className=" mt-2">
              <TermCodesChart startDate={formatLocalISODate(showingRange?.from)} endDate={formatLocalISODate(showingRange?.to)} />
            </div>
            <div className=" mt-2">
              <AgentLeaderBoardTable startDate={formatLocalISODate(showingRange?.from)} endDate={formatLocalISODate(showingRange?.to)} />
            </div>
            <div className=" mt-2">
              <ServiceChart startDate={formatLocalISODate(showingRange?.from)} endDate={formatLocalISODate(showingRange?.to)} />
            </div>
          </div>
        </div>
        {/* </div> */}
      </div>
    </>
  );
};

export default DashHomePage;