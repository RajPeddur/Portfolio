// src/types.ts
export interface CallRecord {
  id: string;
  agent: string;
  assignTo: string;
  timestamp: string; // ISO string
  duration: string; // mm:ss
  durationSeconds: number;
  flagged: boolean;
  tags: string[];
  note?: string;
}

export interface Filters {
  agent: string;
  assignTo: string;
  dateFrom: string | null; // yyyy-mm-dd
  dateTo: string | null;
  duration: string; // e.g. "00:10"
  tags: string[];
  flagged: "" | "true" | "false";
}


const AGENTS = [
  "Saurabh Tiwari","Harsh Pablo","Riyaz Thobani","Akshay Joshi","Priya Choudhury",
  "Rohan Desai","Siddharth Rao","Ayesha Sharma","Arjun Mehra","Kavya Reddy","Isha Patel"
];

const TAG_POOL = [
  "Escalation Language","MMD","REC","Agent: RPC Check","Do Not Call","Wrong Number",
  "Legal Action","Risk and Abusive","Payment Dispute","Voicemail","Overtalk","Settlement Language"
];

function randInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function formatDuration(seconds: number) {
  const mm = Math.floor(seconds / 60).toString().padStart(2, "0");
  const ss = (seconds % 60).toString().padStart(2, "0");
  return `${mm}:${ss}`;
}

export default function mockDataGenerator(count = 100, startId = 0): CallRecord[] {
  const now = Date.now();
  return Array.from({ length: count }).map((_, i) => {
    const seconds = randInt(5, 600);
    const timestamp = new Date(now - randInt(0, 1000 * 60 * 60 * 24 * 30)).toISOString();
    const tags: string[] = [];
    if (Math.random() > 0.7) tags.push(TAG_POOL[randInt(0, TAG_POOL.length - 1)]);
    if (Math.random() > 0.95) tags.push(TAG_POOL[randInt(0, TAG_POOL.length - 1)]);
    return {
      id: `r-${startId + i}`,
      agent: AGENTS[randInt(0, AGENTS.length - 1)],
      assignTo: Math.random() > 0.6 ? "Team A" : "Team B",
      timestamp,
      duration: formatDuration(seconds),
      durationSeconds: seconds,
      flagged: Math.random() > 0.85,
      tags,
      note: Math.random() > 0.8 ? "Wrong Number" : "",
    } as CallRecord;
  });
}

export { TAG_POOL };
