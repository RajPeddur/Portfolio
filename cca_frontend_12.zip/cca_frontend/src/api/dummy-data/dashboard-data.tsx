
export const statData = [
    {
      title: 'Total calls',
      icon: 'PhoneIcon',
      count: '2500',
      percent: '10',
      growth: true
    },
    {
      title: 'Dead Air Ratio',
      icon: 'UserIcon',
      count: '12%',
      percent: '20',
      growth: false
    },
    {
      title: 'Avg Handle Time',
      icon: 'ClockIcon',
      count: '82.41',
      percent: '30',
      growth: true
    },
    {
      title: 'Avg Sentiment',
      icon: 'UserIcon',
      count: '77.26',
      percent: '25',
      growth: true
    },
    {
      title: 'Flagged calls',
      icon: 'FlagIcon',
      count: '37.43',
      percent: '7',
      growth: true
    },
  ]