export const menuData = [
  {
    title: "Analytics",
    icon: "ChartBarSquareIcon",
    children: [
      { title: "Dashboard", icon: "ChartBarSquareIcon", path: "/dashboard" },
      { title: "Reports", icon: "FolderIcon", path: "/dashboard/reports" },
      { title: "Scorecard", icon: "StarIcon", path: "/dashboard/scorecard" },
    ],
  },
  {
    title: "Operations",
    icon: "PhoneIcon",
    children: [
      { title: "Calls", icon: "PhoneIcon", path: "/dashboard/calls" },
      { title: "Inbox", icon: "EnvelopeIcon", path: "/dashboard/inbox" },
    ],
  },
  {
    title: "Admin",
    icon: "Settings",
    children: [
      { title: "User Management", icon: "UsersIcon", path: "/dashboard/users" },
      { title: "Setting", icon: "Cog6ToothIcon", path: "/dashboard/setting" },
    ],
  },
];

