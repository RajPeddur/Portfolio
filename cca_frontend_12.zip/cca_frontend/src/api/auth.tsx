import apiClient from "./apiClient";

interface LoginPayload {
  email: string;
  password: string;
}

// ✅ Example mock login API (replace with real API endpoint)
export const loginAPI = async (payload: LoginPayload) => {
  // simulate API call with timeout
  await new Promise((resolve) => setTimeout(resolve, 1000));

  if (payload?.email === "admin@cca.com" && payload?.password === "Test@123") {
    return {
      email: payload.email,
      token: "mock-jwt-token-12345",
    };
  } else {
    throw new Error("The email or password you entered is incorrect.");
  }
};


// export const loginApi = async (payload: { email: string; password: string }) => {
//   const response = await apiClient.post("/login", payload);
//   return response.data; // assuming response contains { token: "...", user: {...} }
// };

// ✅ Example real API usage
export const getProfileAPI = async () => {
  const response = await apiClient.get("/profile");
  return response.data;
};
