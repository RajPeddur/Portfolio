export const localData = {
    add(key: string, value: any) {
        localStorage.setItem(key, JSON.stringify(value));
    },

    remove(key: string) {
        localStorage.removeItem(key);
    },

    load(key: string) {
        if (typeof window !== 'undefined') {
            const stored = localStorage.getItem(key);
            return (stored == null || stored === undefined || stored === "undefined")
                ? undefined
                : JSON.parse(stored);
        }
        return undefined;
    },
};

export const formatLocalISODate = (d?: Date | null) => {
  if (!d) return "";
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0"); // months are 0-based
  const day = String(d.getDate()).padStart(2, "0");
//   return `${year}-${month}-${day}`;
  return `${day}-${month}-${year}`;
};
