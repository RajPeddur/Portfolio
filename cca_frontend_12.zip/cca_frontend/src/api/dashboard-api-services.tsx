import { statData } from "./dummy-data/dashboard-data"

export const dashboardStatDataGetAPI = () => {
  return new Promise(async (resolve, reject) => {
    try {
      resolve(statData)
    } catch (error) {
      reject(error)
    }
  })
}