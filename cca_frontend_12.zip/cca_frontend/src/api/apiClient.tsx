import axios from "axios";
import toast from "react-hot-toast";
import { localData } from "./utils";
export const BaseUrl = `https://api.cca.com`;

// ✅ Base API configuration
const apiClient = axios.create({
    baseURL: BaseUrl,
    headers: {
        "Content-Type": "application/json",
    },
});

apiClient.interceptors.request.use(
  (config) => {
    const user = localData.load("user");
    if (user?.token) {
      config.headers.Authorization = `Bearer ${user.token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// 🔹 Handle 401 globally
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      toast.error("Session expired, logging out...");
      localData.remove("user");
      window.location.href = "/login";
    }
    return Promise.reject(error);
  }
);

export default apiClient;
