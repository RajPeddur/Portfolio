// import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import { Toaster } from "react-hot-toast";
// import Login from "./pages/login";
// import ProtectedRoute from "./components/route";
// import Dashboard from "./pages/dashboard";
// import { ThemeProvider } from "./context/theme-context";

// function App() {
//   return (
//     <ThemeProvider>
//         <Router>
//           <Routes>
//             <Route path="/" element={<Login />} />
//             <Route
//               path="/dashboard"
//               element={
//                 <ProtectedRoute>
//                   <Dashboard />
//                 </ProtectedRoute>
//               }
//             />
//           </Routes>
//         </Router>
//         <Toaster position="top-right" reverseOrder={false} />
//     </ThemeProvider>
//   );
// }

// export default App;


import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import Login from "./pages/login";
import Dashboard from "./pages/dashboard";
import ProtectedRoute from "./components/route";
import { ThemeProvider } from "./context/theme-context";
import ComingSoonPage from "./pages/coming-soon-page";
import DashHomePage from "./pages/dash-home-page";
import ReportPage from "./pages/report-page";
import "../css/css.css"
import CallsPage from "./pages/calls-page";

function App() {
  return (
    <ThemeProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          >
            <Route index element={<DashHomePage />} />
            <Route path="reports" element={<ReportPage />} />
            <Route path="scorecard" element={<ComingSoonPage />} />
            <Route path="calls" element={<CallsPage />} />
            <Route path="inbox" element={<ComingSoonPage />} />
            <Route path="users" element={<ComingSoonPage />} />
            <Route path="setting" element={<ComingSoonPage />} />
          </Route>
        </Routes>
      </Router>
      <Toaster position="top-right" reverseOrder={false} />
    </ThemeProvider>
  );
}

export default App;
