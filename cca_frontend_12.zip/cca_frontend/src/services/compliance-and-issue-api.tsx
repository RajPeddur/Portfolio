import { baseApi } from "./base-api";

export interface ComplianceAndIssueRecord {
  label: string;
  calls: number;
  rate: number;
}

export interface ComplianceAndIssueResponse {
  code: string;
  message: string;
  data: {
    timeRange: string;
    records: ComplianceAndIssueRecord[];
  };
}

export const ComplianceAndIssueApi = baseApi.injectEndpoints({
  endpoints: (item) => ({
    getComplianceAndIssue: item.query<ComplianceAndIssueResponse, { startDate: string; endDate: string }>({
      queryFn: async ({ startDate, endDate }) => {
        // ✅ Stubbed response for now; replace with actual API later
        await new Promise((r) => setTimeout(r, 500));

        const response: ComplianceAndIssueResponse = {
          code: "200",
          message: "Success",
          data: {
            timeRange: `${startDate} to ${endDate}`,
            records: [
              { label: "no-RPC", calls: 1480, rate: 2 },
              { label: "Agent: RPC Check", calls: 2300, rate: 2 },
              { label: "MMD", calls: 568, rate: 2 },
              { label: "Borrower: RPC Confirmation", calls: 754, rate: 2 },
              { label: "no-MMD", calls: 2435, rate: 2 },
              { label: "REC", calls: 674, rate: 2 },
              { label: "no-REC", calls: 865, rate: 2 },
              { label: "Incomplete MMD", calls: 696, rate: 2 },
              { label: "no-Consumer Verification", calls: 832, rate: 2 },
            ],
          },
        };

        return { data: response };
      },
    }),
  }),
});

export const { useGetComplianceAndIssueQuery } = ComplianceAndIssueApi;
