import { baseApi } from "./base-api";

export interface TermCodesRecord {
  label: string;
  calls: number;
}

export interface TermCodesResponse {
  code: string;
  message: string;
  data: {
    timeRange: string;
    records: TermCodesRecord[];
  };
}

export const TermCodesApi = baseApi.injectEndpoints({
  endpoints: (item) => ({
    getTermCodes: item.query<TermCodesResponse, { startDate: string; endDate: string }>({
      queryFn: async ({ startDate, endDate }) => {
        // ✅ Stubbed response for now; replace with actual API later
        await new Promise((r) => setTimeout(r, 500));

        const response: TermCodesResponse = {
          code: "200",
          message: "Success",
          data: {
            timeRange: `${startDate} to ${endDate}`,
            records: [
              { label: "Wrong Number", calls: 1000 },
              { label: "Left Voicemail", calls: 420 },
              { label: "No Answer", calls: 1180, },
              { label: "Hung Up", calls: 900, },
            ],
          },
        };

        return { data: response };
      },
    }),
  }),
});

export const { useGetTermCodesQuery } = TermCodesApi;
