import { baseApi } from "./base-api";

export interface AgentLeaderboardRecord {
    id: number;
    rank: number;
    agent:string;
    totalCall: number;
    qaScore: string;
}

export interface AgentLeaderboardResponse {
    code: string;
    message: string;
    data: {
        timeRange: string;
        records: AgentLeaderboardRecord[];
    };
}

export const AgentLeaderboardApi = baseApi.injectEndpoints({
    endpoints: (item) => ({
        getAgentLeaderboard: item.query<AgentLeaderboardResponse, { startDate: string; endDate: string }>({
            queryFn: async ({ startDate, endDate }) => {
                // ✅ Stubbed response for now; replace with actual API later
                await new Promise((r) => setTimeout(r, 500));

                const response: AgentLeaderboardResponse = {
                    code: "200",
                    message: "Success",
                    data: {
                        timeRange: `${startDate} to ${endDate}`,
                        records: [
                            {
                                id: 1,
                                rank: 1,
                                agent: "Agent Name",
                                totalCall: 235,
                                qaScore: "10/10"
                            },
                            {
                                id: 2,
                                rank: 2,
                                agent: "Agent Name",
                                totalCall: 210,
                                qaScore: "9/10"
                            },
                            {
                                id: 3,
                                rank: 3,
                                agent: "Agent Name",
                                totalCall: 205,
                                qaScore: "8/10"
                            },
                            {
                                id: 4,
                                rank: 4,
                                agent: "Agent Name",
                                totalCall: 190,
                                qaScore: "7/10"
                            },
                            {
                                id: 5,
                                rank: 5,
                                agent: "Agent Name",
                                totalCall: 185,
                                qaScore: "6/10"
                            },
                            {
                                id: 6,
                                rank: 6,
                                agent: "Agent Name",
                                totalCall: 180,
                                qaScore: "5/10"
                            },
                            {
                                id: 7,
                                rank: 7,
                                agent: "Agent Name",
                                totalCall: 170,
                                qaScore: "4/10"
                            },
                        ],
                    },
                };

                return { data: response };
            },
        }),
    }),
});

export const { useGetAgentLeaderboardQuery } = AgentLeaderboardApi;
