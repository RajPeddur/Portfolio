// import { baseApi } from "./base-api";
import type { QueryReturnValue } from "@reduxjs/toolkit/query";
import { baseApi } from "./base-api";

export interface ServiceRecord {
  label: string;
  calls: number;
  avgSeconds: number;
}

export interface ServiceResponse {
  code: string;
  message: string;
  data: {
    timeRange: string;
    records: ServiceRecord[];
  };
}

const useStub = true;

export const callInsightsApi = baseApi.injectEndpoints({
  endpoints: (item) => ({
    getServiceData: item.query<ServiceResponse, { startDate: string; endDate: string }>({
      // ✅ explicitly type queryFn’s return to satisfy TS
      async queryFn({ startDate, endDate }): Promise<
        QueryReturnValue<ServiceResponse>
      > {
        try {
          if (useStub) {
            await new Promise((r) => setTimeout(r, 500));

            const response: ServiceResponse = {
              code: "200",
              message: "Success",
              data: {
                timeRange: `${startDate} to ${endDate}`,
                records: [
                  { label: "Outbound", calls: 2000, avgSeconds: 10 },
                  { label: "Inbound", calls: 1000, avgSeconds: 20 },
                ],
              },
            };

            // ✅ Correct structure
            return { data: response };
          }

          const res = await fetch(
            `/api/call-insights/duration?startDate=${startDate}&endDate=${endDate}`
          );

          if (!res.ok) {
            return {
              error: { status: res.status, data: await res.text() },
            };
          }

          const data: ServiceResponse = await res.json();
          return { data };
        } catch (err: any) {
          return {
            error: { status: "CUSTOM_ERROR", data: err.message },
          };
        }
      },
      providesTags: ["CallInsights"],
    }),
  }),
});

export const { useGetServiceDataQuery } = callInsightsApi;
