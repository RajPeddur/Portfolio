// Committed code will be use when real API stub
// import { baseApi } from "./base-api";

export const loadThemeConfig = async (tenantId?: string) => {
  const path = `/config/theme/${tenantId || 'default'}.json`;

  const response = await fetch(path);
  if (!response.ok) {
    throw new Error(`Failed to load theme config: ${response.status}`);
  }

  const theme = await response.json();
  return theme;
};

// export interface CallDurationRecord {
//   label: string;
//   calls: number;
//   avgSeconds: number;
// }

// export interface CallDurationResponse {
//   code: string;
//   message: string;
//   data: {
//     timeRange: string;
//     records: CallDurationRecord[];
//   };
// }

// const useStub = true;

// export const callInsightsApi = baseApi.injectEndpoints({
//   endpoints: (builder) => ({
//     getCallDurationData: builder.query<CallDurationResponse, { startDate: string; endDate: string }>({
//       async queryFn({ startDate, endDate }) {
//         if (useStub) {
//           await new Promise((r) => setTimeout(r, 500));

//           const response: CallDurationResponse = {
//             code: "200",
//             message: "Success",
//             data: {
//               timeRange: `${startDate} to ${endDate}`,
//               records: [
//                 { label: "01 Sep", calls: 1200, avgSeconds: 45 },
//                 { label: "02 Sep", calls: 950, avgSeconds: 38 },
//                 { label: "03 Sep", calls: 1850, avgSeconds: 55 },
//                 { label: "04 Sep", calls: 1350, avgSeconds: 47 },
//                 { label: "05 Sep", calls: 1650, avgSeconds: 60 },
//               ],
//             },
//           };

//           return { data: response };
//         }

//         try {
//           const res = await fetch(
//             `/api/call-insights/duration?startDate=${startDate}&endDate=${endDate}`
//           );
//           const data: CallDurationResponse = await res.json();
//           return { data };
//         } catch (error: any) {
//           return { error: { status: "CUSTOM_ERROR", data: error.message } };
//         }
//       },
//       providesTags: ["CallInsights"],
//     }),
//   }),
// });

// export const { useGetCallDurationDataQuery } = callInsightsApi;

