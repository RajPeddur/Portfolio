// import { baseApi } from "./base-api";
import type { QueryReturnValue } from "@reduxjs/toolkit/query";
import { baseApi } from "./base-api";

export interface CallDurationRecord {
  label: string;
  calls: number;
  avgSeconds: number;
}

export interface CallDurationResponse {
  code: string;
  message: string;
  data: {
    timeRange: string;
    records: CallDurationRecord[];
  };
}

const useStub = true;

export const callInsightsApi = baseApi.injectEndpoints({
  endpoints: (item) => ({
    getCallDurationData: item.query<CallDurationResponse, { startDate: string; endDate: string }>({
      // ✅ explicitly type queryFn’s return to satisfy TS
      async queryFn({ startDate, endDate }): Promise<
        QueryReturnValue<CallDurationResponse>
      > {
        try {
          if (useStub) {
            await new Promise((r) => setTimeout(r, 500));

            const response: CallDurationResponse = {
              code: "200",
              message: "Success",
              data: {
                timeRange: `${startDate} to ${endDate}`,
                records: [
                  { label: "10s", calls: 1200, avgSeconds: 10 },
                  { label: "20s", calls: 1800, avgSeconds: 20 },
                  { label: "30s", calls: 2900, avgSeconds: 30 },
                  { label: "40s", calls: 2100, avgSeconds: 40 },
                  { label: "50s", calls: 2600, avgSeconds: 50 },
                  { label: "60s", calls: 3100, avgSeconds: 60 },
                  { label: "70s", calls: 3600, avgSeconds: 70 },
                  { label: "80s", calls: 3200, avgSeconds: 80 },
                  { label: "90s", calls: 3400, avgSeconds: 90 },
                ],
              },
            };

            // ✅ Correct structure
            return { data: response };
          }

          const res = await fetch(
            `/api/call-insights/duration?startDate=${startDate}&endDate=${endDate}`
          );

          if (!res.ok) {
            return {
              error: { status: res.status, data: await res.text() },
            };
          }

          const data: CallDurationResponse = await res.json();
          return { data };
        } catch (err: any) {
          return {
            error: { status: "CUSTOM_ERROR", data: err.message },
          };
        }
      },
      providesTags: ["CallInsights"],
    }),
  }),
});

export const { useGetCallDurationDataQuery } = callInsightsApi;
