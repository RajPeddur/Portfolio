import { baseApi } from "./base-api";

export interface CallInsightsRecord {
  label: string;
  calls: number;
}

export interface CallInsightsResponse {
  code: string;
  message: string;
  data: {
    timeRange: string;
    records: CallInsightsRecord[];
  };
}

export const callInsightsApi = baseApi.injectEndpoints({
  endpoints: (item) => ({
    getCallInsights: item.query<CallInsightsResponse, { startDate: string; endDate: string }>({
      queryFn: async ({ startDate, endDate }) => {
        // ✅ Stubbed response for now; replace with actual API later
        await new Promise((r) => setTimeout(r, 500));

        const response: CallInsightsResponse = {
          code: "200",
          message: "Success",
          data: {
            timeRange: `${startDate} to ${endDate}`,
            records: [
              { label: "Payment Discussion", calls: 1480 },
              { label: "Payment Dispute", calls: 2300 },
              { label: "Refusal to Pay", calls: 568 },
              { label: "Settlement Language", calls: 754 },
              { label: "Payment Plan", calls: 2435 },
              { label: "Adhere UDAA Disclosure", calls: 674 },
              { label: "Call Back Language", calls: 865 },
              { label: "Validation of Debt", calls: 696 },
              { label: "Promise To Pay", calls: 832 },
              { label: "Pandemic Discussion", calls: 912 },
              { label: "Hung up while on Hold", calls: 632 },
              { label: "Right Party Good Calls", calls: 453 },
            ],
          },
        };

        return { data: response };
      },
    }),
  }),
});

export const { useGetCallInsightsQuery } = callInsightsApi;
