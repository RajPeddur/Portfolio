// This component will use when real API stub
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const baseApi = createApi({
  reducerPath: "api",
  baseQuery: fetchBaseQuery({
    baseUrl: "/api", // your backend root URL (proxy configured in Vite or CRA)
  }),
  tagTypes: ["CallInsights", "User", "Reports"], // tags for cache invalidation
  endpoints: () => ({}), // other APIs will inject endpoints here
});
