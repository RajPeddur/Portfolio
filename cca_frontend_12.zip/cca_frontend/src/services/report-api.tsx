// src/services/reports-api.ts
import { baseApi } from "./base-api";

export interface ReportItem {
  id: string;
  name: string;
  description: string;
  createdBy: string;
  scheduled: boolean;
  scheduleLabel?: string | null;
  pdfUrl?: string | null;
  excelUrl?: string | null;
}

export interface ReportsResponse {
  code: string;
  message: string;
  data: ReportItem[];
}

export const ReportsApi = baseApi.injectEndpoints({
  endpoints: (builder) => ({
    getReports: builder.query<ReportsResponse, void>({
      async queryFn() {
        // ✅ Stubbed data for now; replace with real API call later
        await new Promise((r) => setTimeout(r, 500));

        const mockData: ReportsResponse = {
          code: "200",
          message: "Success",
          data: [
            {
              id: "r1",
              name: "QA Review Report",
              description: "All escalated/flagged calls for QA review",
              createdBy: "admin@company.com",
              scheduled: false,
            },
            {
              id: "r2",
              name: "Scorecard Summary",
              description: "Agent and team performance scores (weekly)",
              createdBy: "qa.lead@company.com",
              scheduled: true,
              scheduleLabel: "Every Monday, 9:00 AM",
            },
            {
              id: "r3",
              name: "Call Details Export",
              description: "Detailed call list, includes all filters",
              createdBy: "supervisor@company.com",
              scheduled: false,
            },
            {
              id: "r4",
              name: "Monthly QA Export",
              description: "All QA reports for the month",
              createdBy: "qa.lead@company.com",
              scheduled: true,
              scheduleLabel: "1st of Month, 10:00 AM",
            },
          ],
        };

        return { data: mockData };
      },
    }),
  }),
});

export const { useGetReportsQuery } = ReportsApi;
