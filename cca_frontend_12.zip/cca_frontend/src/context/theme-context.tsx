// src/context/ThemeContext.tsx
import React, { createContext, useContext, useEffect, useState } from "react";
import { loadThemeConfig } from "../services/theme-service";

const ThemeContext = createContext<any>(null);
export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const [theme, setTheme] = useState<any>(null);

  useEffect(() => {
    (async () => {
      const config = await loadThemeConfig();
      setTheme(config);
      applyCSSVariables(config);
    })();
  }, []);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

const applyCSSVariables = (theme: any) => {
  if (!theme) return;
  const root = document.documentElement;
  Object.entries(theme).forEach(([key, value]) => {
    root.style.setProperty(`--${key}`, value as string);
  });
};
